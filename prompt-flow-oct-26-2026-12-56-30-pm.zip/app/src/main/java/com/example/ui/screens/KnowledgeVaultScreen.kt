package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.CloudDone
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.MemoryCategory
import com.example.model.MemoryItem
import com.example.ui.theme.CriticalCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.IceBlue
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MissPerfectViewModel

@Composable
fun KnowledgeVaultScreen(
  viewModel: MissPerfectViewModel,
  modifier: Modifier = Modifier
) {
  val memories by viewModel.memories.collectAsState()
  val driveStatus by viewModel.driveSyncStatus.collectAsState()

  var searchQuery by remember { mutableStateOf("") }
  var selectedCategory by remember { mutableStateOf<MemoryCategory?>(null) }
  var showAddMemoryDialog by remember { mutableStateOf(false) }
  var memoryToDelete by remember { mutableStateOf<MemoryItem?>(null) }

  val filteredMemories = memories.filter { item ->
    (selectedCategory == null || item.category == selectedCategory) &&
      (searchQuery.isBlank() || item.title.contains(searchQuery, ignoreCase = true) || item.content.contains(searchQuery, ignoreCase = true))
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepVoid)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(CyberCyan.copy(alpha = 0.15f), CircleShape)
          .border(1.dp, CyberCyan, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Folder, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = "Knowledge Vault & Memories",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "Local-First Persistent Vault & Optional Drive Sync",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
      // Google Drive & Privacy Status Card
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
          modifier = Modifier.fillMaxWidth().testTag("drive_bridge_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Security, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Privacy & Storage Architecture", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
              }
              Surface(color = SuccessEmerald.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp)) {
                Text("100% Private", modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp), color = SuccessEmerald, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = "All memories, research notebooks, and chats are stored locally inside SQLite Room Database. External cloud providers cannot read local data without explicit user authorization.",
              color = TextSecondary,
              fontSize = 11.sp,
              lineHeight = 16.sp
            )

            Spacer(modifier = Modifier.height(10.dp))
            Surface(
              color = DarkSurface,
              shape = RoundedCornerShape(10.dp),
              modifier = Modifier.fillMaxWidth()
            ) {
              Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Cloud, contentDescription = null, tint = IceBlue, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text("Google Drive Vault Bridge", color = TextPrimary, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                  Text("Status: $driveStatus", color = TextTertiary, fontSize = 10.sp)
                }
              }
            }
          }
        }
      }

      // Search & Add Bar
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search memories...", color = TextTertiary, fontSize = 12.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextTertiary, modifier = Modifier.size(18.dp)) },
            modifier = Modifier.weight(1f).testTag("memory_search_field"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = DarkSurfaceElevated,
              unfocusedContainerColor = DarkSurfaceElevated,
              focusedBorderColor = CyberCyan,
              unfocusedBorderColor = Color(0xFF282C40),
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(14.dp),
            singleLine = true
          )

          Button(
            onClick = { showAddMemoryDialog = true },
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier.testTag("add_memory_button")
          ) {
            Icon(Icons.Default.Add, contentDescription = null, tint = DeepVoid, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Add", color = DeepVoid, fontSize = 12.sp)
          }
        }
      }

      // Categories Row
      item {
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          FilterChip(
            selected = selectedCategory == null,
            onClick = { selectedCategory = null },
            label = { Text("All", fontSize = 11.sp) },
            colors = FilterChipDefaults.filterChipColors(
              selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
              selectedLabelColor = TextPrimary
            )
          )
          MemoryCategory.values().take(3).forEach { cat ->
            FilterChip(
              selected = selectedCategory == cat,
              onClick = { selectedCategory = if (selectedCategory == cat) null else cat },
              label = { Text(cat.label, fontSize = 11.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = CyberCyan.copy(alpha = 0.2f),
                selectedLabelColor = TextPrimary
              )
            )
          }
        }
      }

      // Memory Items
      items(filteredMemories, key = { it.id }) { mem ->
        Card(
          shape = RoundedCornerShape(14.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth().testTag("memory_card_${mem.id}")
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = mem.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary
              )

              IconButton(
                onClick = { memoryToDelete = mem },
                modifier = Modifier.size(28.dp)
              ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete memory", tint = TextTertiary, modifier = Modifier.size(16.dp))
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(text = mem.content, style = MaterialTheme.typography.bodySmall, color = TextSecondary, lineHeight = 18.sp)
            Spacer(modifier = Modifier.height(8.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
              Text(mem.category.label, color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
              Text("Source: ${mem.provenance}", color = TextTertiary, fontSize = 10.sp)
            }
          }
        }
      }
    }
  }

  // Delete Confirmation Dialog (as requested by brief: "Do not overwrite or delete important files without confirmation")
  memoryToDelete?.let { mem ->
    Dialog(onDismissRequest = { memoryToDelete = null }) {
      Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, CriticalCrimson.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth().testTag("delete_memory_dialog")
      ) {
        Column(modifier = Modifier.padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text("Confirm Memory Deletion", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)
          Spacer(modifier = Modifier.height(8.dp))
          Text("Are you sure you want to permanently delete \"${mem.title}\" from your private Knowledge Vault?", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
          Spacer(modifier = Modifier.height(16.dp))

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(
              onClick = { memoryToDelete = null },
              modifier = Modifier.weight(1f)
            ) {
              Text("Cancel")
            }

            Button(
              onClick = {
                viewModel.deleteMemory(mem)
                memoryToDelete = null
              },
              colors = ButtonDefaults.buttonColors(containerColor = CriticalCrimson),
              modifier = Modifier.weight(1f).testTag("confirm_delete_memory_button")
            ) {
              Text("Delete", color = Color.White)
            }
          }
        }
      }
    }
  }

  // Add Memory Dialog
  if (showAddMemoryDialog) {
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(MemoryCategory.PERSONAL) }

    Dialog(onDismissRequest = { showAddMemoryDialog = false }) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
          Text("Add to Private Memory Vault", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)

          OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Memory Title") },
            modifier = Modifier.fillMaxWidth().testTag("new_memory_title_field")
          )

          OutlinedTextField(
            value = content,
            onValueChange = { content = it },
            label = { Text("Content & Details") },
            modifier = Modifier.fillMaxWidth().height(100.dp).testTag("new_memory_content_field")
          )

          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
            Button(
              onClick = {
                if (title.isNotBlank()) {
                  viewModel.addMemory(category, title, content)
                  showAddMemoryDialog = false
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
              modifier = Modifier.testTag("save_memory_button")
            ) {
              Text("Save Memory", color = DeepVoid)
            }
          }
        }
      }
    }
  }
}
