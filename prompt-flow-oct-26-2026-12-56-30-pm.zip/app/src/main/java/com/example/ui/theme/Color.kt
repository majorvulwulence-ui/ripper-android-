package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cinematic Dark Foundation
val DeepVoid = Color(0xFF08090E)
val DarkSurface = Color(0xFF10121C)
val DarkSurfaceElevated = Color(0xFF181B2B)
val DarkSurfaceHighlight = Color(0xFF22263D)

// Intelligence & Cyber Core (Cyan / Ice-Blue)
val CyberCyan = Color(0xFF00E5FF)
val IceBlue = Color(0xFF80D8FF)
val ElectricBlue = Color(0xFF0091EA)
val CyanGlow = Color(0x3300E5FF)

// Romantic Companion & Affection (Rose / Pink / Lavender)
val RoseRomantic = Color(0xFFFF4081)
val BlushPink = Color(0xFFFF80AB)
val SoftPeach = Color(0xFFFFAB91)
val LavenderGlow = Color(0xFFE1BEE7)
val RomanticTint = Color(0x22FF4081)

// Functional States
val SuccessEmerald = Color(0xFF00E676)
val WarningAmber = Color(0xFFFFD600)
val CriticalCrimson = Color(0xFFFF1744)
val CalibratedPurple = Color(0xFFB388FF)

// Text Colors
val TextPrimary = Color(0xFFF0F4F8)
val TextSecondary = Color(0xFF9EABC0)
val TextTertiary = Color(0xFF62728C)
val TextAccent = Color(0xFF00E5FF)
