package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.Lightbulb
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Science
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.CitationSource
import com.example.model.EpistemicStatus
import com.example.model.ResearchEntry
import com.example.ui.theme.CalibratedPurple
import com.example.ui.theme.CriticalCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.IceBlue
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MissPerfectViewModel

@Composable
fun MindLabScreen(
  viewModel: MissPerfectViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("🧬 Bioscience", "🔬 Research", "🧠 Philosophy", "💡 Curiosity")

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepVoid)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(CyberCyan.copy(alpha = 0.15f), CircleShape)
          .border(1.dp, CyberCyan, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Science, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = "Mind Lab — Science & Philosophy",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "Evidence-Oriented Reasoning & Bioscience Protocols",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }
    }

    // Tabs
    ScrollableTabRow(
      selectedTabIndex = selectedTab,
      containerColor = DarkSurfaceElevated,
      contentColor = CyberCyan,
      edgePadding = 16.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = {
            Text(
              text = title,
              fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
              color = if (selectedTab == index) CyberCyan else TextSecondary,
              fontSize = 13.sp
            )
          },
          modifier = Modifier.testTag("mind_lab_tab_$index")
        )
      }
    }

    // Content
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)
    ) {
      when (selectedTab) {
        0 -> BioscienceToolsTab(viewModel)
        1 -> ResearchNotebookTab(viewModel)
        2 -> PhilosophyWorkspaceTab(viewModel)
        3 -> CuriosityQueueTab(viewModel)
      }
    }
  }
}

@Composable
fun BioscienceToolsTab(viewModel: MissPerfectViewModel) {
  var subTool by remember { mutableIntStateOf(0) }
  val subTools = listOf("DNA Translation", "CRISPR-Cas9", "Enzyme Kinetics", "ATP Stoichiometry")

  val dnaInput by viewModel.dnaInput.collectAsState()
  val dnaResult by viewModel.dnaResult.collectAsState()
  val crisprInput by viewModel.crisprInput.collectAsState()
  val crisprTargets by viewModel.crisprTargets.collectAsState()
  val enzymeKm by viewModel.enzymeKm.collectAsState()
  val enzymeVmax by viewModel.enzymeVmax.collectAsState()
  val enzymeResult by viewModel.enzymeResult.collectAsState()
  val glucoseCount by viewModel.glucoseMolecules.collectAsState()
  val atpResult by viewModel.atpResult.collectAsState()

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        subTools.forEachIndexed { idx, title ->
          Button(
            onClick = { subTool = idx },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (subTool == idx) CyberCyan else DarkSurfaceElevated
            ),
            modifier = Modifier.weight(1f).testTag("bio_subtool_$idx")
          ) {
            Text(
              text = title.split(" ")[0],
              fontSize = 11.sp,
              color = if (subTool == idx) DeepVoid else TextPrimary,
              maxLines = 1
            )
          }
        }
      }
    }

    when (subTool) {
      0 -> {
        // DNA Translation Tool
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "DNA to mRNA & Polypeptide Translation",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = CyberCyan
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Converts input nucleotide sequence to codons and identifies corresponding amino acid sequence.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
              )
              Spacer(modifier = Modifier.height(12.dp))

              OutlinedTextField(
                value = dnaInput,
                onValueChange = { viewModel.setDnaInput(it) },
                label = { Text("DNA Coding Sequence (5' -> 3')") },
                modifier = Modifier.fillMaxWidth().testTag("dna_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = DarkSurface,
                  unfocusedContainerColor = DarkSurface,
                  focusedBorderColor = CyberCyan,
                  unfocusedBorderColor = Color(0xFF282C40),
                  focusedTextColor = TextPrimary,
                  unfocusedTextColor = TextPrimary
                )
              )

              Spacer(modifier = Modifier.height(14.dp))

              dnaResult?.let { res ->
                Text("Transcribed mRNA: ${res.mrna}", color = IceBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                Spacer(modifier = Modifier.height(6.dp))
                Text("Polypeptide Sequence:", color = TextSecondary, fontSize = 12.sp)
                Text(res.polypeptideSequence, color = SuccessEmerald, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween
                ) {
                  Text("GC Content: ${"%.1f".format(res.gcContentPercent)}%", color = TextSecondary, fontSize = 12.sp)
                  Text("Est. Mass: ${"%.0f".format(res.molecularWeightEstimateDa)} Da", color = TextSecondary, fontSize = 12.sp)
                }
              }
            }
          }
        }
      }
      1 -> {
        // CRISPR-Cas9 Tool
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, RoseRomantic.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "CRISPR-SpCas9 Protospacer & PAM Scanner",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = RoseRomantic
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Identifies NGG PAM recognition sites and yields 20-nt guide RNA sequences with GC scoring.",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
              )
              Spacer(modifier = Modifier.height(12.dp))

              OutlinedTextField(
                value = crisprInput,
                onValueChange = { viewModel.setCrisprInput(it) },
                label = { Text("Target Locus Sequence") },
                modifier = Modifier.fillMaxWidth().testTag("crispr_input_field"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = DarkSurface,
                  unfocusedContainerColor = DarkSurface,
                  focusedBorderColor = RoseRomantic,
                  unfocusedBorderColor = Color(0xFF282C40),
                  focusedTextColor = TextPrimary,
                  unfocusedTextColor = TextPrimary
                )
              )

              Spacer(modifier = Modifier.height(14.dp))

              Text("Discovered Targets (${crisprTargets.size}):", color = TextPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
              Spacer(modifier = Modifier.height(8.dp))

              if (crisprTargets.isEmpty()) {
                Text("No NGG PAM sites detected in given sequence.", color = TextTertiary, fontSize = 12.sp)
              } else {
                crisprTargets.take(5).forEach { target ->
                  Surface(
                    color = DarkSurface,
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2A2E44)),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                  ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                      Text("Pos ${target.position}: 5'-${target.protospacer20nt}-[${target.pamSite}]-3'", color = IceBlue, fontSize = 11.sp, fontWeight = FontWeight.SemiBold)
                      Spacer(modifier = Modifier.height(2.dp))
                      Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                      ) {
                        Text("GC%: ${"%.1f".format(target.gcContentPercent)}%", color = TextSecondary, fontSize = 11.sp)
                        Text("Quality: ${target.qualityScore}/100", color = if (target.qualityScore >= 80) SuccessEmerald else WarningAmber, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
      2 -> {
        // Enzyme Kinetics Tool
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "Michaelis-Menten Enzyme Kinetics Simulator",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = CyberCyan
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "V = (Vmax * [S]) / (Km + [S])",
                style = MaterialTheme.typography.bodySmall,
                color = IceBlue,
                fontWeight = FontWeight.SemiBold
              )

              Spacer(modifier = Modifier.height(14.dp))

              Text("Km (Michaelis Constant): ${"%.1f".format(enzymeKm)} mM", color = TextPrimary, fontSize = 12.sp)
              Slider(
                value = enzymeKm.toFloat(),
                onValueChange = { viewModel.setEnzymeParams(it.toDouble(), enzymeVmax) },
                valueRange = 1f..30f,
                colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
              )

              Spacer(modifier = Modifier.height(8.dp))

              Text("Vmax (Max Velocity): ${"%.1f".format(enzymeVmax)} umol/min", color = TextPrimary, fontSize = 12.sp)
              Slider(
                value = enzymeVmax.toFloat(),
                onValueChange = { viewModel.setEnzymeParams(enzymeKm, it.toDouble()) },
                valueRange = 5f..80f,
                colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
              )

              Spacer(modifier = Modifier.height(12.dp))

              enzymeResult?.let { res ->
                Surface(
                  color = DarkSurface,
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)
                ) {
                  Column(modifier = Modifier.padding(12.dp)) {
                    Text("Half-Max Velocity (at [S]=Km): ${"%.2f".format(res.halfMaxVelocity)} umol/min", color = SuccessEmerald, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Text("Lineweaver-Burk Slope (Km/Vmax): ${"%.4f".format(res.lineweaverBurkSlope)}", color = TextSecondary, fontSize = 12.sp)
                    Text("Lineweaver-Burk Y-Intercept (1/Vmax): ${"%.4f".format(res.lineweaverBurkYIntercept)}", color = TextSecondary, fontSize = 12.sp)
                  }
                }
              }
            }
          }
        }
      }
      3 -> {
        // ATP Yield Calculator
        item {
          Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
            border = androidx.compose.foundation.BorderStroke(1.dp, CalibratedPurple.copy(alpha = 0.4f)),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(16.dp)) {
              Text(
                text = "Cellular Respiration ATP Stoichiometry",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = CalibratedPurple
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                text = "Glycolysis -> Pyruvate Dehydrogenase -> Krebs Cycle -> Oxidative Phosphorylation",
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
              )

              Spacer(modifier = Modifier.height(14.dp))

              Text("Glucose Molecules: $glucoseCount", color = TextPrimary, fontSize = 13.sp)
              Slider(
                value = glucoseCount.toFloat(),
                onValueChange = { viewModel.setGlucoseCount(it.toInt()) },
                valueRange = 1f..10f,
                steps = 8,
                colors = SliderDefaults.colors(thumbColor = CalibratedPurple, activeTrackColor = CalibratedPurple)
              )

              Spacer(modifier = Modifier.height(12.dp))

              atpResult?.let { atp ->
                Surface(
                  color = DarkSurface,
                  shape = RoundedCornerShape(10.dp),
                  modifier = Modifier.fillMaxWidth()
                ) {
                  Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Glycolysis Net ATP: ${atp.glycolysisAtpNet} ATP", color = TextPrimary, fontSize = 12.sp)
                    Text("Glycolysis NADH: ${atp.glycolysisNadh} NADH", color = TextSecondary, fontSize = 12.sp)
                    Text("Pyruvate Oxidation NADH: ${atp.pyruvateOxidationNadh} NADH", color = TextSecondary, fontSize = 12.sp)
                    Text("Krebs Cycle ATP/GTP: ${atp.krebsCycleAtpGtp} ATP", color = TextPrimary, fontSize = 12.sp)
                    Text("Krebs Cycle NADH: ${atp.krebsCycleNadh} NADH | FADH2: ${atp.krebsCycleFadh2} FADH2", color = TextSecondary, fontSize = 12.sp)
                    Text("Oxidative Phosphorylation Yield: ${"%.1f".format(atp.oxidativePhosphorylationAtp)} ATP", color = IceBlue, fontSize = 12.sp)
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Total Net ATP Generated: ~${"%.0f".format(atp.totalAtpTheoretical)} ATP", color = SuccessEmerald, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                  }
                }
              }
            }
          }
        }
      }
    }
  }
}

@Composable
fun ResearchNotebookTab(viewModel: MissPerfectViewModel) {
  val entries by viewModel.researchEntries.collectAsState()
  var showNewEntryDialog by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize()) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
        text = "Calibrated Research Entries (${entries.size})",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )

      Button(
        onClick = { showNewEntryDialog = true },
        colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
        modifier = Modifier.testTag("new_research_button")
      ) {
        Icon(Icons.Default.Add, contentDescription = null, tint = DeepVoid, modifier = Modifier.size(16.dp))
        Spacer(modifier = Modifier.width(4.dp))
        Text("New Entry", color = DeepVoid, fontSize = 12.sp)
      }
    }

    Spacer(modifier = Modifier.height(12.dp))

    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      items(entries, key = { it.id }) { item ->
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(
                text = item.title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextPrimary,
                modifier = Modifier.weight(1f)
              )

              Surface(
                shape = RoundedCornerShape(8.dp),
                color = when (item.epistemicStatus) {
                  EpistemicStatus.FACT -> SuccessEmerald.copy(alpha = 0.15f)
                  EpistemicStatus.HYPOTHESIS -> WarningAmber.copy(alpha = 0.15f)
                  EpistemicStatus.INFERENCE -> CyberCyan.copy(alpha = 0.15f)
                  else -> CalibratedPurple.copy(alpha = 0.15f)
                }
              ) {
                Text(
                  text = item.epistemicStatus.label,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = when (item.epistemicStatus) {
                    EpistemicStatus.FACT -> SuccessEmerald
                    EpistemicStatus.HYPOTHESIS -> WarningAmber
                    EpistemicStatus.INFERENCE -> CyberCyan
                    else -> CalibratedPurple
                  }
                )
              }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Text("Question: ${item.question}", color = TextSecondary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Hypothesis: ${item.hypothesis}", color = IceBlue, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Method: ${item.method}", color = TextTertiary, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Result: ${item.result}", color = TextPrimary, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Text("Limitations: ${item.limitations}", color = TextSecondary, fontSize = 11.sp)

            if (item.citations.isNotEmpty()) {
              Spacer(modifier = Modifier.height(8.dp))
              Text("Citations:", color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              item.citations.forEach { cit ->
                Text("• ${cit.title} (${cit.publisher})", color = CyberCyan, fontSize = 10.sp)
              }
            }
          }
        }
      }
    }
  }

  if (showNewEntryDialog) {
    var title by remember { mutableStateOf("") }
    var question by remember { mutableStateOf("") }
    var hypothesis by remember { mutableStateOf("") }
    var method by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("") }

    Dialog(onDismissRequest = { showNewEntryDialog = false }) {
      Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.5f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
          Text("New Research Formulation", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = TextPrimary)

          OutlinedTextField(
            value = title,
            onValueChange = { title = it },
            label = { Text("Investigation Title") },
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = question,
            onValueChange = { question = it },
            label = { Text("Core Question") },
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = hypothesis,
            onValueChange = { hypothesis = it },
            label = { Text("Hypothesis & Assumptions") },
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = method,
            onValueChange = { method = it },
            label = { Text("Methodology") },
            modifier = Modifier.fillMaxWidth()
          )

          OutlinedTextField(
            value = result,
            onValueChange = { result = it },
            label = { Text("Observed / Calibrated Result") },
            modifier = Modifier.fillMaxWidth()
          )

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.End
          ) {
            Button(
              onClick = {
                if (title.isNotBlank()) {
                  viewModel.addResearchEntry(
                    title = title,
                    question = question,
                    hypothesis = hypothesis,
                    prediction = "Expected verified behavior",
                    method = method,
                    dataSource = "Experimental Empirical / Simulation dataset",
                    result = result,
                    limitations = "Constrained sample size",
                    conclusion = "Calibrated hypothesis validated",
                    status = EpistemicStatus.HYPOTHESIS,
                    citations = listOf(CitationSource("PubMed BioRxiv Repository", "National Library of Medicine", "2024", "https://pubmed.ncbi.nlm.nih.gov/"))
                  )
                  showNewEntryDialog = false
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = CyberCyan)
            ) {
              Text("Save to Vault", color = DeepVoid)
            }
          }
        }
      }
    }
  }
}

@Composable
fun PhilosophyWorkspaceTab(viewModel: MissPerfectViewModel) {
  val experiments by viewModel.thoughtExperiments.collectAsState()

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, RoseRomantic.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "AI System & Epistemic Disclosure",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = RoseRomantic
          )
          Spacer(modifier = Modifier.height(6.dp))
          Text(
            text = "Notice on Intelligence: Agentic reasoning, semantic synthesis, and persistent memory in MISS PERFECT are engineered software capabilities. They do not substantiate phenomenal human consciousness, qualia, or subjective feelings.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            lineHeight = 18.sp
          )
        }
      }
    }

    item {
      Text(
        text = "Classic Thought Experiments & Dialectic",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    }

    items(experiments, key = { it.id }) { exp ->
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2B2E42)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(text = exp.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = IceBlue)
          Spacer(modifier = Modifier.height(2.dp))
          Text(text = "Domain: ${exp.domain}", style = MaterialTheme.typography.bodySmall, color = CalibratedPurple, fontSize = 11.sp)
          Spacer(modifier = Modifier.height(8.dp))
          Text(text = exp.scenario, style = MaterialTheme.typography.bodyMedium, color = TextPrimary, lineHeight = 19.sp)
          Spacer(modifier = Modifier.height(10.dp))

          Surface(
            color = DarkSurface,
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Text("Key Dialectic Questions:", color = TextTertiary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              exp.questions.forEach { q ->
                Text("• $q", color = TextSecondary, fontSize = 11.sp)
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text("Miss Perfect Analysis:", color = CyberCyan, fontSize = 10.sp, fontWeight = FontWeight.Bold)
              Text(exp.dialecticSummary, color = SuccessEmerald, fontSize = 11.sp)
            }
          }
        }
      }
    }
  }
}

@Composable
fun CuriosityQueueTab(viewModel: MissPerfectViewModel) {
  val queue by viewModel.curiosityQueue.collectAsState()

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(10.dp)
  ) {
    item {
      Text(
        text = "Curiosity Queue (Questions to Revisit)",
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextPrimary
      )
    }

    items(queue, key = { it.id }) { item ->
      Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Row(
          modifier = Modifier.padding(14.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(Icons.Default.Lightbulb, contentDescription = null, tint = WarningAmber, modifier = Modifier.size(24.dp))
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(item.question, color = TextPrimary, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold)
            Spacer(modifier = Modifier.height(2.dp))
            Text(item.category, color = TextTertiary, fontSize = 11.sp)
          }
        }
      }
    }
  }
}
