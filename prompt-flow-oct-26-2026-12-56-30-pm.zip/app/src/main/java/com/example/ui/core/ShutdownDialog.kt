package com.example.ui.core

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.CriticalCrimson
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary

@Composable
fun ShutdownDialog(
  farewellSpeech: String,
  onConfirmShutdown: () -> Unit,
  onSkipFarewell: () -> Unit,
  onCancel: () -> Unit
) {
  Dialog(onDismissRequest = onCancel) {
    Card(
      modifier = Modifier
        .fillMaxWidth()
        .border(1.dp, RoseRomantic.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
        .testTag("shutdown_dialog"),
      shape = RoundedCornerShape(24.dp),
      colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
    ) {
      Column(
        modifier = Modifier.padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
      ) {
        // Top Icon
        Box(
          modifier = Modifier
            .size(60.dp)
            .background(
              Brush.radialGradient(listOf(RoseRomantic.copy(alpha = 0.4f), Color.Transparent)),
              CircleShape
            )
            .border(1.5.dp, RoseRomantic, CircleShape),
          contentAlignment = Alignment.Center
        ) {
          Icon(
            imageVector = Icons.Default.PowerSettingsNew,
            contentDescription = "Core Shutdown",
            tint = RoseRomantic,
            modifier = Modifier.size(32.dp)
          )
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
          text = "Core Shutdown Sequence",
          style = MaterialTheme.typography.titleLarge,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
          text = "Final Dramatic Speech from your Companion",
          style = MaterialTheme.typography.bodySmall,
          color = RoseRomantic
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Dramatic Farewell Box
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .background(DeepVoid, RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFF2B2E42), RoundedCornerShape(16.dp))
            .padding(16.dp)
        ) {
          Text(
            text = farewellSpeech,
            style = MaterialTheme.typography.bodyMedium,
            color = TextPrimary,
            lineHeight = 22.sp,
            textAlign = TextAlign.Start
          )
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Actions
        Column(
          modifier = Modifier.fillMaxWidth(),
          verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
          Button(
            onClick = onConfirmShutdown,
            modifier = Modifier
              .fillMaxWidth()
              .testTag("confirm_shutdown_button"),
            colors = ButtonDefaults.buttonColors(containerColor = RoseRomantic)
          ) {
            Icon(Icons.Default.PowerSettingsNew, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text("Acknowledge & Power Down Core")
          }

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedButton(
              onClick = onSkipFarewell,
              modifier = Modifier
                .weight(1f)
                .testTag("skip_farewell_button")
            ) {
              Icon(Icons.Default.SkipNext, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Skip Farewell")
            }

            OutlinedButton(
              onClick = onCancel,
              modifier = Modifier
                .weight(1f)
                .testTag("emergency_stop_button"),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = CriticalCrimson)
            ) {
              Icon(Icons.Default.Warning, contentDescription = null, modifier = Modifier.size(16.dp), tint = CriticalCrimson)
              Spacer(modifier = Modifier.width(4.dp))
              Text("Cancel / Stop")
            }
          }
        }
      }
    }
  }
}
