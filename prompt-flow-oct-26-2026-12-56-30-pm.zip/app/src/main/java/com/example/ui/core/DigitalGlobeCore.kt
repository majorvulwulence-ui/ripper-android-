package com.example.ui.core

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.model.CompanionMode
import com.example.model.CoreStatus
import com.example.ui.theme.BlushPink
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.IceBlue
import com.example.ui.theme.RoseRomantic
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

@Composable
fun DigitalGlobeCore(
  coreStatus: CoreStatus,
  mode: CompanionMode,
  isSpeaking: Boolean,
  isListening: Boolean,
  isBlushing: Boolean,
  speechAmplitude: Float,
  modifier: Modifier = Modifier,
  globeSize: Dp = 220.dp
) {
  val infiniteTransition = rememberInfiniteTransition(label = "core_anim")

  // Core Pulse
  val pulseScale by infiniteTransition.animateFloat(
    initialValue = 0.88f,
    targetValue = 1.12f,
    animationSpec = infiniteRepeatable(
      animation = tween(if (isSpeaking) 600 else 1800, easing = LinearEasing),
      repeatMode = RepeatMode.Reverse
    ),
    label = "pulse_scale"
  )

  // Orbital Ring Rotations
  val rotationRing1 by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(if (coreStatus == CoreStatus.SHUTDOWN) 24000 else 7000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "ring_rot_1"
  )

  val rotationRing2 by infiniteTransition.animateFloat(
    initialValue = 360f,
    targetValue = 0f,
    animationSpec = infiniteRepeatable(
      animation = tween(if (coreStatus == CoreStatus.SHUTDOWN) 30000 else 9000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "ring_rot_2"
  )

  val rotationRing3 by infiniteTransition.animateFloat(
    initialValue = 0f,
    targetValue = 360f,
    animationSpec = infiniteRepeatable(
      animation = tween(12000, easing = LinearEasing),
      repeatMode = RepeatMode.Restart
    ),
    label = "ring_rot_3"
  )

  // Floating Particles
  val particleSeed = remember {
    List(24) {
      val angle = Random.nextFloat() * 2f * PI.toFloat()
      val dist = Random.nextFloat() * 0.8f + 0.2f
      val speed = Random.nextFloat() * 1.5f + 0.5f
      Triple(angle, dist, speed)
    }
  }

  // Determine Primary Colors according to state
  val isOffline = coreStatus == CoreStatus.SHUTDOWN
  val primaryColor = when {
    isOffline -> Color(0xFF424250)
    isBlushing -> BlushPink
    mode == CompanionMode.GIRLFRIEND -> RoseRomantic
    else -> CyberCyan
  }

  val secondaryColor = when {
    isOffline -> Color(0xFF282835)
    isBlushing -> RoseRomantic
    mode == CompanionMode.GIRLFRIEND -> BlushPink
    else -> IceBlue
  }

  Box(
    modifier = modifier.size(globeSize),
    contentAlignment = Alignment.Center
  ) {
    Canvas(modifier = Modifier.fillMaxSize()) {
      val center = Offset(size.width / 2f, size.height / 2f)
      val radius = (size.minDimension / 2f) * 0.85f

      if (isOffline) {
        // Dim offline sphere
        drawCircle(
          brush = Brush.radialGradient(
            colors = listOf(Color(0xFF2A2D3C), Color(0xFF141620), Color.Transparent),
            center = center,
            radius = radius * 0.6f
          ),
          radius = radius * 0.6f,
          center = center
        )
        drawCircle(
          color = Color(0xFF42475E),
          radius = radius * 0.6f,
          center = center,
          style = Stroke(width = 2f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(10f, 10f)))
        )
        return@Canvas
      }

      // Outer Glow Halo
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            primaryColor.copy(alpha = if (isSpeaking) 0.35f else 0.18f),
            secondaryColor.copy(alpha = 0.08f),
            Color.Transparent
          ),
          center = center,
          radius = radius * 1.15f
        ),
        radius = radius * 1.15f,
        center = center
      )

      // Inner Luminous Core
      val coreRadius = (radius * 0.42f) * if (isSpeaking) (pulseScale + (speechAmplitude * 0.3f)) else pulseScale
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(
            Color.White.copy(alpha = 0.95f),
            secondaryColor.copy(alpha = 0.85f),
            primaryColor.copy(alpha = 0.65f),
            Color.Transparent
          ),
          center = center,
          radius = coreRadius
        ),
        radius = coreRadius,
        center = center
      )

      // Rotating Orbital Rings (Ellipse Projections)
      rotate(degrees = rotationRing1, pivot = center) {
        drawOval(
          brush = Brush.sweepGradient(
            listOf(primaryColor, secondaryColor.copy(alpha = 0.2f), primaryColor),
            center = center
          ),
          topLeft = Offset(center.x - radius, center.y - (radius * 0.45f)),
          size = Size(radius * 2f, radius * 0.9f),
          style = Stroke(width = 2.5f)
        )
        // Orbital node points
        val nodeX = center.x + radius
        val nodeY = center.y
        drawCircle(color = Color.White, radius = 4f, center = Offset(nodeX, nodeY))
      }

      rotate(degrees = rotationRing2 + 45f, pivot = center) {
        drawOval(
          brush = Brush.sweepGradient(
            listOf(secondaryColor, primaryColor.copy(alpha = 0.3f), secondaryColor),
            center = center
          ),
          topLeft = Offset(center.x - (radius * 0.92f), center.y - (radius * 0.65f)),
          size = Size(radius * 1.84f, radius * 1.3f),
          style = Stroke(width = 2.0f)
        )
        val nodeX2 = center.x - (radius * 0.92f)
        val nodeY2 = center.y
        drawCircle(color = primaryColor, radius = 3.5f, center = Offset(nodeX2, nodeY2))
      }

      rotate(degrees = rotationRing3 - 30f, pivot = center) {
        drawOval(
          color = primaryColor.copy(alpha = 0.45f),
          topLeft = Offset(center.x - (radius * 0.75f), center.y - (radius * 0.85f)),
          size = Size(radius * 1.5f, radius * 1.7f),
          style = Stroke(width = 1.5f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(12f, 8f)))
        )
      }

      // Constellation / Particle Field
      particleSeed.forEachIndexed { index, (baseAngle, baseDist, speed) ->
        val currentAngle = baseAngle + (rotationRing1 * 0.015f * speed)
        val pDist = radius * baseDist
        val px = center.x + (pDist * cos(currentAngle))
        val py = center.y + (pDist * sin(currentAngle) * 0.7f)
        val pAlpha = (0.35f + (0.5f * sin(currentAngle * 2f))).coerceIn(0.2f, 0.95f)

        drawCircle(
          color = if (index % 2 == 0) primaryColor.copy(alpha = pAlpha) else secondaryColor.copy(alpha = pAlpha),
          radius = if (index % 3 == 0) 3f else 2f,
          center = Offset(px, py)
        )
      }

      // Audio reactive waveform bars at bottom of core
      if (isSpeaking || isListening) {
        val barCount = 14
        val totalWidth = radius * 1.2f
        val startX = center.x - (totalWidth / 2f)
        val barWidth = totalWidth / (barCount * 1.6f)
        val barBaseY = center.y + (radius * 0.85f)

        for (i in 0 until barCount) {
          val factor = sin(((i.toFloat() / barCount) * PI).toFloat())
          val amp = if (isSpeaking) (pulseScale * 25f * factor) else (speechAmplitude * 35f * factor)
          val barHeight = (8f + amp).coerceIn(4f, 40f)

          val bx = startX + (i * barWidth * 1.6f)
          drawLine(
            color = if (isListening) CyberCyan else primaryColor,
            start = Offset(bx, barBaseY - (barHeight / 2f)),
            end = Offset(bx, barBaseY + (barHeight / 2f)),
            strokeWidth = barWidth * 0.75f
          )
        }
      }
    }
  }
}
