package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val MissPerfectColorScheme = darkColorScheme(
  primary = CyberCyan,
  onPrimary = DeepVoid,
  primaryContainer = DarkSurfaceElevated,
  onPrimaryContainer = IceBlue,
  secondary = RoseRomantic,
  onSecondary = Color.White,
  secondaryContainer = DarkSurfaceHighlight,
  onSecondaryContainer = BlushPink,
  tertiary = CalibratedPurple,
  onTertiary = DeepVoid,
  background = DeepVoid,
  onBackground = TextPrimary,
  surface = DarkSurface,
  onSurface = TextPrimary,
  surfaceVariant = DarkSurfaceElevated,
  onSurfaceVariant = TextSecondary,
  error = CriticalCrimson,
  onError = Color.White
)

@Composable
fun MissPerfectTheme(
  content: @Composable () -> Unit
) {
  MaterialTheme(
    colorScheme = MissPerfectColorScheme,
    typography = Typography,
    content = content
  )
}
