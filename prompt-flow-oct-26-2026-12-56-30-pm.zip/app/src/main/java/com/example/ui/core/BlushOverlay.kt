package com.example.ui.core

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import com.example.ui.theme.BlushPink
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.SoftPeach
import kotlin.random.Random

@Composable
fun BlushOverlay(
  isBlushing: Boolean,
  intensity: Float,
  enabled: Boolean,
  modifier: Modifier = Modifier
) {
  if (!enabled) return

  val particles = remember {
    List(16) {
      Offset(Random.nextFloat(), Random.nextFloat())
    }
  }

  AnimatedVisibility(
    visible = isBlushing,
    enter = fadeIn(animationSpec = tween(600)),
    exit = fadeOut(animationSpec = tween(900)),
    modifier = modifier.fillMaxSize()
  ) {
    Box(
      modifier = Modifier
        .fillMaxSize()
        .background(
          Brush.radialGradient(
            colors = listOf(
              Color.Transparent,
              SoftPeach.copy(alpha = 0.08f * intensity),
              BlushPink.copy(alpha = 0.18f * intensity),
              RoseRomantic.copy(alpha = 0.28f * intensity)
            )
          )
        )
    ) {
      Canvas(modifier = Modifier.fillMaxSize()) {
        particles.forEachIndexed { index, normPos ->
          val px = normPos.x * size.width
          val py = normPos.y * size.height
          val heartColor = if (index % 2 == 0) BlushPink else RoseRomantic

          // Floating soft hearts / glowing sparkles
          drawCircle(
            color = heartColor.copy(alpha = 0.45f * intensity),
            radius = if (index % 3 == 0) 6f else 4f,
            center = Offset(px, py)
          )
        }
      }
    }
  }
}
