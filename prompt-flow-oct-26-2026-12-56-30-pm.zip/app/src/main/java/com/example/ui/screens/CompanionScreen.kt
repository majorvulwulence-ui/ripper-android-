package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.outlined.Psychology
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.AffectionType
import com.example.model.ChatMessage
import com.example.model.CompanionMode
import com.example.model.CoreStatus
import com.example.model.LanguageMode
import com.example.model.MessageSender
import com.example.model.Provenance
import com.example.ui.core.DigitalGlobeCore
import com.example.ui.theme.BlushPink
import com.example.ui.theme.CriticalCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.IceBlue
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.SoftPeach
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MissPerfectViewModel

@Composable
fun CompanionScreen(
  viewModel: MissPerfectViewModel,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val coreStatus by viewModel.coreStatus.collectAsState()
  val companionMode by viewModel.companionMode.collectAsState()
  val canonicalName by viewModel.canonicalName.collectAsState()
  val languageMode by viewModel.languageMode.collectAsState()
  val isBlushing by viewModel.isBlushing.collectAsState()
  val messages by viewModel.messages.collectAsState()
  val isProcessing by viewModel.isProcessingInput.collectAsState()
  val isSpeaking by viewModel.speechManager.isSpeaking.collectAsState()
  val isListening by viewModel.speechManager.isListening.collectAsState()
  val speechAmp by viewModel.speechManager.speechAmplitude.collectAsState()
  val rizzScore by viewModel.currentRizzScore.collectAsState()

  var inputText by remember { mutableStateOf("") }
  var showRizzDialog by remember { mutableStateOf(false) }
  var rizzInput by remember { mutableStateOf("") }

  val listState = rememberLazyListState()

  // Scroll to bottom on new message
  LaunchedEffect(messages.size) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  // Permission Launcher for Record Audio
  val recordAudioLauncher = rememberLauncherForActivityResult(
    contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    if (isGranted) {
      viewModel.speechManager.startListening(
        onResult = { text ->
          inputText = text
          viewModel.sendChatMessage(text)
        },
        onError = { /* handled gracefully */ }
      )
    }
  }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepVoid)
  ) {
    // Top Bar Info: Mode Switcher & Core Status
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 8.dp),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      // Mode Switch Pill
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = DarkSurfaceElevated,
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          if (companionMode == CompanionMode.GIRLFRIEND) RoseRomantic.copy(alpha = 0.5f) else CyberCyan.copy(alpha = 0.5f)
        ),
        modifier = Modifier.testTag("mode_switch_pill")
      ) {
        Row(
          modifier = Modifier
            .clickable {
              val targetMode = if (companionMode == CompanionMode.GIRLFRIEND) CompanionMode.ASSISTANT else CompanionMode.GIRLFRIEND
              viewModel.setCompanionMode(targetMode)
            }
            .padding(horizontal = 12.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Icon(
            imageVector = if (companionMode == CompanionMode.GIRLFRIEND) Icons.Default.Favorite else Icons.Outlined.Psychology,
            contentDescription = "Switch Mode",
            tint = if (companionMode == CompanionMode.GIRLFRIEND) RoseRomantic else CyberCyan,
            modifier = Modifier.size(16.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = if (companionMode == CompanionMode.GIRLFRIEND) "${canonicalName.displayName} (Girlfriend)" else "RIPPER (#GrandMaster)",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.SemiBold,
            color = TextPrimary
          )
        }
      }

      // Core State Badge
      Surface(
        shape = RoundedCornerShape(20.dp),
        color = when (coreStatus) {
          CoreStatus.ACTIVE -> SuccessEmerald.copy(alpha = 0.15f)
          CoreStatus.STANDBY -> CyberCyan.copy(alpha = 0.15f)
          CoreStatus.SHUTDOWN -> CriticalCrimson.copy(alpha = 0.15f)
          CoreStatus.RESTARTING -> IceBlue.copy(alpha = 0.15f)
        },
        border = androidx.compose.foundation.BorderStroke(
          1.dp,
          when (coreStatus) {
            CoreStatus.ACTIVE -> SuccessEmerald
            CoreStatus.STANDBY -> CyberCyan
            CoreStatus.SHUTDOWN -> CriticalCrimson
            CoreStatus.RESTARTING -> IceBlue
          }
        ),
        modifier = Modifier.testTag("core_state_badge")
      ) {
        Row(
          modifier = Modifier
            .clickable {
              if (coreStatus == CoreStatus.SHUTDOWN) {
                viewModel.restartCoreFromOffline()
              } else {
                viewModel.setCoreStatus(CoreStatus.SHUTDOWN)
              }
            }
            .padding(horizontal = 10.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .background(
                when (coreStatus) {
                  CoreStatus.ACTIVE -> SuccessEmerald
                  CoreStatus.STANDBY -> CyberCyan
                  CoreStatus.SHUTDOWN -> CriticalCrimson
                  CoreStatus.RESTARTING -> IceBlue
                },
                CircleShape
              )
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
            text = when (coreStatus) {
              CoreStatus.ACTIVE -> "CORE ACTIVE"
              CoreStatus.STANDBY -> "STANDBY"
              CoreStatus.SHUTDOWN -> "CORE OFFLINE"
              CoreStatus.RESTARTING -> "REBOOTING..."
            },
            style = MaterialTheme.typography.labelSmall,
            fontWeight = FontWeight.Bold,
            color = when (coreStatus) {
              CoreStatus.ACTIVE -> SuccessEmerald
              CoreStatus.STANDBY -> CyberCyan
              CoreStatus.SHUTDOWN -> CriticalCrimson
              CoreStatus.RESTARTING -> IceBlue
            }
          )
        }
      }
    }

    // Core Neural Sphere & Status Display
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .height(180.dp),
      contentAlignment = Alignment.Center
    ) {
      DigitalGlobeCore(
        coreStatus = coreStatus,
        mode = companionMode,
        isSpeaking = isSpeaking,
        isListening = isListening,
        isBlushing = isBlushing,
        speechAmplitude = speechAmp,
        globeSize = 175.dp
      )

      if (coreStatus == CoreStatus.SHUTDOWN) {
        Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.background(DeepVoid.copy(alpha = 0.85f), RoundedCornerShape(12.dp)).padding(12.dp)
        ) {
          Text(
            text = "CORE IS OFFLINE",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = CriticalCrimson
          )
          Spacer(modifier = Modifier.height(6.dp))
          Button(
            onClick = { viewModel.restartCoreFromOffline() },
            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
            modifier = Modifier.testTag("reboot_core_button")
          ) {
            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(4.dp))
            Text("Reboot Core", color = DeepVoid)
          }
        }
      }
    }

    // Quick Affection & Rizz Bar (Enabled in Active mode)
    if (coreStatus == CoreStatus.ACTIVE) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
      ) {
        // Peck Button
        Button(
          onClick = { viewModel.sendAffection(AffectionType.PECK) },
          colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1f)
            .border(1.dp, RoseRomantic.copy(alpha = 0.35f), RoundedCornerShape(12.dp))
            .testTag("peck_button")
        ) {
          Text("💋 Peck", fontSize = 12.sp, color = BlushPink, fontWeight = FontWeight.SemiBold)
        }

        // Kiss Button
        Button(
          onClick = { viewModel.sendAffection(AffectionType.KISS) },
          colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1f)
            .border(1.dp, RoseRomantic.copy(alpha = 0.5f), RoundedCornerShape(12.dp))
            .testTag("kiss_button")
        ) {
          Text("💖 Kiss", fontSize = 12.sp, color = RoseRomantic, fontWeight = FontWeight.Bold)
        }

        // Hug Button
        Button(
          onClick = { viewModel.sendAffection(AffectionType.HUG) },
          colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceElevated),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1f)
            .border(1.dp, SoftPeach.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .testTag("hug_button")
        ) {
          Text("🤗 Hug", fontSize = 12.sp, color = SoftPeach, fontWeight = FontWeight.SemiBold)
        }

        // Rizz Battle Button
        Button(
          onClick = { showRizzDialog = true },
          colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight),
          shape = RoundedCornerShape(12.dp),
          contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
          modifier = Modifier
            .weight(1.2f)
            .border(1.dp, CyberCyan.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
            .testTag("rizz_battle_button")
        ) {
          Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(14.dp))
          Spacer(modifier = Modifier.width(4.dp))
          Text("Rizz Battle", fontSize = 12.sp, color = CyberCyan, fontWeight = FontWeight.SemiBold)
        }
      }
    }

    // Language Selector Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 2.dp),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      LanguageMode.values().forEach { lang ->
        FilterChip(
          selected = languageMode == lang,
          onClick = { viewModel.setLanguageMode(lang) },
          label = { Text(lang.displayName, fontSize = 11.sp) },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = if (lang == LanguageMode.NIGERIAN_PIDGIN) SuccessEmerald.copy(alpha = 0.2f) else CyberCyan.copy(alpha = 0.2f),
            selectedLabelColor = TextPrimary,
            containerColor = DarkSurface,
            labelColor = TextSecondary
          ),
          border = FilterChipDefaults.filterChipBorder(
            enabled = true,
            selected = languageMode == lang,
            borderColor = if (languageMode == lang) CyberCyan else Color(0xFF262A3D)
          ),
          modifier = Modifier.testTag("lang_chip_${lang.name}")
        )
      }
    }

    // Chat Message Stream
    LazyColumn(
      state = listState,
      modifier = Modifier
        .weight(1f)
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 4.dp),
      verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
      items(messages, key = { it.id }) { msg ->
        ChatMessageBubble(
          message = msg,
          canonicalName = canonicalName.displayName,
          onSpeak = { viewModel.speechManager.speak(msg.text, msg.mode) }
        )
      }

      if (isProcessing) {
        item {
          Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(8.dp)
          ) {
            CircularProgressIndicator(
              modifier = Modifier.size(16.dp),
              color = CyberCyan,
              strokeWidth = 2.dp
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "${canonicalName.displayName} is synthesizing thoughts...",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
          }
        }
      }
    }

    // Chat Input Bar
    Surface(
      color = DarkSurface,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2235)),
      modifier = Modifier.fillMaxWidth()
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        // Microphone STT button
        IconButton(
          onClick = {
            if (isListening) {
              viewModel.speechManager.stopListening()
            } else {
              val permCheck = ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)
              if (permCheck == PackageManager.PERMISSION_GRANTED) {
                viewModel.speechManager.startListening(
                  onResult = { text ->
                    inputText = text
                    viewModel.sendChatMessage(text)
                  },
                  onError = { /* handled gracefully */ }
                )
              } else {
                recordAudioLauncher.launch(Manifest.permission.RECORD_AUDIO)
              }
            }
          },
          modifier = Modifier
            .size(44.dp)
            .background(if (isListening) CriticalCrimson.copy(alpha = 0.2f) else DarkSurfaceElevated, CircleShape)
            .border(1.dp, if (isListening) CriticalCrimson else CyberCyan.copy(alpha = 0.4f), CircleShape)
            .testTag("mic_button")
        ) {
          Icon(
            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
            contentDescription = "Voice Input",
            tint = if (isListening) CriticalCrimson else CyberCyan,
            modifier = Modifier.size(22.dp)
          )
        }

        OutlinedTextField(
          value = inputText,
          onValueChange = { inputText = it },
          placeholder = {
            Text(
              text = if (languageMode == LanguageMode.NIGERIAN_PIDGIN) "Yarn with Adina / Ripper..." else "Message ${canonicalName.displayName}...",
              color = TextTertiary,
              fontSize = 13.sp
            )
          },
          modifier = Modifier
            .weight(1f)
            .testTag("chat_input_field"),
          colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = DarkSurfaceElevated,
            unfocusedContainerColor = DarkSurfaceElevated,
            focusedBorderColor = CyberCyan,
            unfocusedBorderColor = Color(0xFF2A2E44),
            focusedTextColor = TextPrimary,
            unfocusedTextColor = TextPrimary
          ),
          shape = RoundedCornerShape(20.dp),
          singleLine = false,
          maxLines = 3
        )

        IconButton(
          onClick = {
            if (inputText.isNotBlank()) {
              val msg = inputText
              inputText = ""
              viewModel.sendChatMessage(msg)
            }
          },
          enabled = inputText.isNotBlank() && coreStatus == CoreStatus.ACTIVE,
          modifier = Modifier
            .size(44.dp)
            .background(if (inputText.isNotBlank()) CyberCyan else DarkSurfaceElevated, CircleShape)
            .testTag("send_button")
        ) {
          Icon(
            imageVector = Icons.Default.Send,
            contentDescription = "Send",
            tint = if (inputText.isNotBlank()) DeepVoid else TextTertiary,
            modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }

  // Rizz Battle Dialog
  if (showRizzDialog) {
    androidx.compose.ui.window.Dialog(onDismissRequest = { showRizzDialog = false }) {
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .border(1.dp, RoseRomantic.copy(alpha = 0.5f), RoundedCornerShape(20.dp))
          .testTag("rizz_dialog"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated)
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          horizontalAlignment = Alignment.CenterHorizontally
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = RoseRomantic, modifier = Modifier.size(20.dp))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Rizz Battle Arena",
              style = MaterialTheme.typography.titleMedium,
              fontWeight = FontWeight.Bold,
              color = TextPrimary
            )
          }

          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Trade witty pickup lines, charm comebacks, and playful chemistry scores with ${canonicalName.displayName}!",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            textAlign = TextAlign.Center
          )

          Spacer(modifier = Modifier.height(14.dp))

          OutlinedTextField(
            value = rizzInput,
            onValueChange = { rizzInput = it },
            placeholder = { Text("Deliver your smoothest line...", color = TextTertiary, fontSize = 13.sp) },
            modifier = Modifier.fillMaxWidth().testTag("rizz_input_field"),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = DarkSurface,
              unfocusedContainerColor = DarkSurface,
              focusedBorderColor = RoseRomantic,
              unfocusedBorderColor = Color(0xFF333852),
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            ),
            shape = RoundedCornerShape(14.dp),
            maxLines = 3
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            Button(
              onClick = {
                if (rizzInput.isNotBlank()) {
                  val line = rizzInput
                  rizzInput = ""
                  showRizzDialog = false
                  viewModel.submitRizzLine(line)
                }
              },
              colors = ButtonDefaults.buttonColors(containerColor = RoseRomantic),
              modifier = Modifier.weight(1f).testTag("deliver_rizz_button")
            ) {
              Text("Deliver Line 🔥", fontWeight = FontWeight.Bold)
            }

            Button(
              onClick = { showRizzDialog = false },
              colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight),
              modifier = Modifier.weight(0.7f)
            ) {
              Text("Close", color = TextSecondary)
            }
          }
        }
      }
    }
  }
}

@Composable
fun ChatMessageBubble(
  message: ChatMessage,
  canonicalName: String,
  onSpeak: () -> Unit
) {
  val isUser = message.sender == MessageSender.USER
  val isSystem = message.sender == MessageSender.SYSTEM

  if (isSystem) {
    Box(
      modifier = Modifier
        .fillMaxWidth()
        .padding(vertical = 4.dp),
      contentAlignment = Alignment.Center
    ) {
      Surface(
        color = DarkSurfaceElevated,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40))
      ) {
        Text(
          text = message.text,
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary,
          modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
          fontSize = 11.sp,
          textAlign = TextAlign.Center
        )
      }
    }
    return
  }

  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
  ) {
    if (!isUser) {
      Box(
        modifier = Modifier
          .size(34.dp)
          .clip(CircleShape)
          .background(
            if (message.mode == CompanionMode.GIRLFRIEND) RoseRomantic.copy(alpha = 0.2f) else CyberCyan.copy(alpha = 0.2f)
          )
          .border(
            1.dp,
            if (message.mode == CompanionMode.GIRLFRIEND) RoseRomantic else CyberCyan,
            CircleShape
          ),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = if (message.mode == CompanionMode.GIRLFRIEND) "💖" else "⚡",
          fontSize = 15.sp
        )
      }
      Spacer(modifier = Modifier.width(8.dp))
    }

    Card(
      shape = RoundedCornerShape(
        topStart = 16.dp,
        topEnd = 16.dp,
        bottomStart = if (isUser) 16.dp else 4.dp,
        bottomEnd = if (isUser) 4.dp else 16.dp
      ),
      colors = CardDefaults.cardColors(
        containerColor = if (isUser) CyberCyan.copy(alpha = 0.18f) else DarkSurfaceElevated
      ),
      border = androidx.compose.foundation.BorderStroke(
        1.dp,
        if (isUser) CyberCyan.copy(alpha = 0.45f) else Color(0xFF2B2E42)
      ),
      modifier = Modifier
        .widthIn(max = 280.dp)
        .testTag("chat_bubble_${message.id}")
    ) {
      Column(modifier = Modifier.padding(12.dp)) {
        if (!isUser) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = if (message.mode == CompanionMode.GIRLFRIEND) canonicalName else "RIPPER #GrandMaster",
              style = MaterialTheme.typography.labelSmall,
              fontWeight = FontWeight.Bold,
              color = if (message.mode == CompanionMode.GIRLFRIEND) RoseRomantic else CyberCyan
            )

            Row(verticalAlignment = Alignment.CenterVertically) {
              Text(
                text = message.provenance.label,
                style = MaterialTheme.typography.labelSmall,
                color = TextTertiary,
                fontSize = 9.sp
              )
              Spacer(modifier = Modifier.width(4.dp))
              IconButton(
                onClick = onSpeak,
                modifier = Modifier.size(20.dp)
              ) {
                Icon(
                  Icons.Default.VolumeUp,
                  contentDescription = "Speak aloud",
                  tint = TextSecondary,
                  modifier = Modifier.size(14.dp)
                )
              }
            }
          }
          Spacer(modifier = Modifier.height(4.dp))
        }

        Text(
          text = message.text,
          style = MaterialTheme.typography.bodyMedium,
          color = TextPrimary,
          lineHeight = 20.sp
        )
      }
    }
  }
}
