package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Restore
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CriticalCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.IceBlue
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.viewmodel.MissPerfectViewModel

@Composable
fun CodeStudioScreen(
  viewModel: MissPerfectViewModel,
  modifier: Modifier = Modifier
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabs = listOf("💻 Code Studio", "🛠️ Self-Development Lab")

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepVoid)
  ) {
    // Top Bar
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(CyberCyan.copy(alpha = 0.15f), CircleShape)
          .border(1.dp, CyberCyan, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Code, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = "Code Studio & Self-Development Lab",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "Isolated Sandbox Execution, Versioning & Verified Diff Inspection",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }
    }

    // Tabs
    ScrollableTabRow(
      selectedTabIndex = selectedTab,
      containerColor = DarkSurfaceElevated,
      contentColor = CyberCyan,
      edgePadding = 16.dp,
      modifier = Modifier.fillMaxWidth()
    ) {
      tabs.forEachIndexed { index, title ->
        Tab(
          selected = selectedTab == index,
          onClick = { selectedTab = index },
          text = {
            Text(
              text = title,
              fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
              color = if (selectedTab == index) CyberCyan else TextSecondary,
              fontSize = 13.sp
            )
          },
          modifier = Modifier.testTag("code_tab_$index")
        )
      }
    }

    // Tab Body
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(16.dp)
    ) {
      if (selectedTab == 0) {
        UserCodeStudioTab(viewModel)
      } else {
        SelfDevelopmentLabTab(viewModel)
      }
    }
  }
}

@Composable
fun UserCodeStudioTab(viewModel: MissPerfectViewModel) {
  val codeText by viewModel.codeEditorText.collectAsState()
  val codeLang by viewModel.codeLanguage.collectAsState()
  val outputText by viewModel.codeOutput.collectAsState()

  val languages = listOf("Kotlin", "Python", "JavaScript", "HTML/CSS")

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    // Language picker
    item {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        languages.forEach { lang ->
          Button(
            onClick = { viewModel.setCodeLanguage(lang) },
            colors = ButtonDefaults.buttonColors(
              containerColor = if (codeLang == lang) CyberCyan else DarkSurfaceElevated
            ),
            modifier = Modifier.weight(1f).testTag("lang_btn_$lang")
          ) {
            Text(
              text = lang,
              fontSize = 11.sp,
              color = if (codeLang == lang) DeepVoid else TextPrimary,
              maxLines = 1
            )
          }
        }
      }
    }

    // Code Editor
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
          ) {
            Text(
              text = "$codeLang Code Editor",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = IceBlue
            )

            Button(
              onClick = { viewModel.executeCodeSandbox() },
              colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
              modifier = Modifier.testTag("run_code_button")
            ) {
              Icon(Icons.Default.PlayArrow, contentDescription = null, tint = DeepVoid, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Run Sandbox", color = DeepVoid, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          OutlinedTextField(
            value = codeText,
            onValueChange = { viewModel.setCodeEditorText(it) },
            modifier = Modifier
              .fillMaxWidth()
              .height(200.dp)
              .testTag("code_editor_field"),
            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
            colors = OutlinedTextFieldDefaults.colors(
              focusedContainerColor = DarkSurface,
              unfocusedContainerColor = DarkSurface,
              focusedBorderColor = CyberCyan,
              unfocusedBorderColor = Color(0xFF2A2E44),
              focusedTextColor = TextPrimary,
              unfocusedTextColor = TextPrimary
            )
          )
        }
      }
    }

    // Execution Console / Output
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurface),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E2235)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(14.dp)) {
          Text(
            text = "Sandbox Console & Output Logs",
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = TextSecondary
          )
          Spacer(modifier = Modifier.height(6.dp))

          Box(
            modifier = Modifier
              .fillMaxWidth()
              .background(DeepVoid, RoundedCornerShape(10.dp))
              .padding(12.dp)
          ) {
            Text(
              text = if (outputText.isNotBlank()) outputText else "Press 'Run Sandbox' to execute algorithm in an isolated container.",
              fontFamily = FontFamily.Monospace,
              fontSize = 11.sp,
              color = if (outputText.isNotBlank()) SuccessEmerald else TextTertiary,
              lineHeight = 16.sp
            )
          }
        }
      }
    }
  }
}

@Composable
fun SelfDevelopmentLabTab(viewModel: MissPerfectViewModel) {
  val diffText by viewModel.selfDevDiff.collectAsState()
  val isPatched by viewModel.selfDevPatched.collectAsState()

  LazyColumn(
    modifier = Modifier.fillMaxSize(),
    verticalArrangement = Arrangement.spacedBy(14.dp)
  ) {
    item {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
        border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.4f)),
        modifier = Modifier.fillMaxWidth()
      ) {
        Column(modifier = Modifier.padding(16.dp)) {
          Text(
            text = "Self-Development & Patch Proposer",
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = CyberCyan
          )
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "Inspect diagnostics, draft module optimizations, review strict unified diffs, test in isolated sandboxes, and apply or rollback changes safely.",
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondary,
            lineHeight = 18.sp
          )

          Spacer(modifier = Modifier.height(14.dp))

          Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(
              onClick = { viewModel.proposeSelfDevPatch() },
              colors = ButtonDefaults.buttonColors(containerColor = CyberCyan),
              modifier = Modifier.weight(1f).testTag("propose_patch_button")
            ) {
              Icon(Icons.Default.Build, contentDescription = null, tint = DeepVoid, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("Draft Patch", color = DeepVoid, fontSize = 12.sp)
            }

            if (diffText.isNotBlank()) {
              Button(
                onClick = { viewModel.applySelfDevPatch() },
                colors = ButtonDefaults.buttonColors(containerColor = SuccessEmerald),
                enabled = !isPatched,
                modifier = Modifier.weight(1f).testTag("apply_patch_button")
              ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DeepVoid, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (isPatched) "Applied" else "Apply Diff", color = DeepVoid, fontSize = 12.sp)
              }
            }
          }

          if (isPatched) {
            Spacer(modifier = Modifier.height(10.dp))
            OutlinedButton(
              onClick = { viewModel.rollbackSelfDevPatch() },
              modifier = Modifier.fillMaxWidth().testTag("rollback_patch_button")
            ) {
              Icon(Icons.Default.Restore, contentDescription = null, tint = CriticalCrimson, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Rollback to Baseline (Safe Recovery)", color = CriticalCrimson, fontSize = 12.sp)
            }
          }
        }
      }
    }

    if (diffText.isNotBlank()) {
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(14.dp)) {
            Text(
              text = "Proposed Unified Code Diff",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = RoseRomantic
            )
            Spacer(modifier = Modifier.height(8.dp))

            Box(
              modifier = Modifier
                .fillMaxWidth()
                .background(DeepVoid, RoundedCornerShape(10.dp))
                .padding(12.dp)
            ) {
              Text(
                text = diffText,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                color = SuccessEmerald,
                lineHeight = 16.sp
              )
            }
          }
        }
      }
    }
  }
}
