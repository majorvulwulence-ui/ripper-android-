package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.RecordVoiceOver
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.CapabilityState
import com.example.model.CompanionCanonicalName
import com.example.model.PersonalityStyle
import com.example.model.UserPreferredName
import com.example.ui.theme.CalibratedPurple
import com.example.ui.theme.CriticalCrimson
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DarkSurfaceHighlight
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.IceBlue
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.SuccessEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.ui.theme.TextTertiary
import com.example.ui.theme.WarningAmber
import com.example.viewmodel.MissPerfectViewModel

@Composable
fun SettingsScreen(
  viewModel: MissPerfectViewModel,
  modifier: Modifier = Modifier
) {
  val canonicalName by viewModel.canonicalName.collectAsState()
  val userNamePref by viewModel.userNamePreference.collectAsState()
  val customName by viewModel.customUserName.collectAsState()
  val personalityStyle by viewModel.personalityStyle.collectAsState()
  val blushEnabled by viewModel.blushEnabled.collectAsState()
  val blushIntensity by viewModel.blushIntensity.collectAsState()
  val autoSpeak by viewModel.autoSpeak.collectAsState()
  val capabilities by viewModel.capabilities.collectAsState()

  var customInput by remember { mutableStateOf(customName) }

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(DeepVoid)
  ) {
    // Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 12.dp),
      verticalAlignment = Alignment.CenterVertically
    ) {
      Box(
        modifier = Modifier
          .size(40.dp)
          .background(CyberCyan.copy(alpha = 0.15f), CircleShape)
          .border(1.dp, CyberCyan, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Icon(Icons.Default.Settings, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(22.dp))
      }
      Spacer(modifier = Modifier.width(12.dp))
      Column {
        Text(
          text = "System Settings & Identity",
          style = MaterialTheme.typography.titleMedium,
          fontWeight = FontWeight.Bold,
          color = TextPrimary
        )
        Text(
          text = "Personalize Names, Romantic Style, Speech & View Registry",
          style = MaterialTheme.typography.bodySmall,
          color = TextSecondary
        )
      }
    }

    LazyColumn(
      modifier = Modifier
        .fillMaxSize()
        .padding(horizontal = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
      // Companion Canonical Name
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth().testTag("companion_name_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Companion Canonical True Name",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = RoseRomantic
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Choose whether her primary romantic identity is Adina or Karima (both trigger Girlfriend mode; Ripper triggers Assistant mode).",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
              CompanionCanonicalName.values().forEach { name ->
                Button(
                  onClick = { viewModel.setCanonicalName(name) },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = if (canonicalName == name) RoseRomantic else DarkSurface
                  ),
                  modifier = Modifier.weight(1f).testTag("name_choice_${name.name}")
                ) {
                  Text(
                    text = name.displayName,
                    fontWeight = FontWeight.Bold,
                    color = if (canonicalName == name) Color.White else TextPrimary
                  )
                }
              }
            }
          }
        }
      }

      // User Addressing Name
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth().testTag("user_name_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "How Miss Perfect Addresses You",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = CyberCyan
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Select preferred addressing: Richard, Rashid, Ariel, natural natural variation, or custom.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              UserPreferredName.values().forEach { pref ->
                Button(
                  onClick = { viewModel.setUserNamePreference(pref) },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = if (userNamePref == pref) CyberCyan else DarkSurface
                  ),
                  modifier = Modifier.weight(1f).testTag("user_pref_${pref.name}")
                ) {
                  Text(
                    text = when (pref) {
                      UserPreferredName.RICHARD -> "Richard"
                      UserPreferredName.RASHID -> "Rashid"
                      UserPreferredName.ARIEL -> "Ariel"
                      UserPreferredName.NATURAL_ROTATION -> "Rotate"
                      UserPreferredName.CUSTOM -> "Custom"
                    },
                    fontSize = 11.sp,
                    color = if (userNamePref == pref) DeepVoid else TextPrimary,
                    maxLines = 1
                  )
                }
              }
            }

            if (userNamePref == UserPreferredName.CUSTOM) {
              Spacer(modifier = Modifier.height(10.dp))
              OutlinedTextField(
                value = customInput,
                onValueChange = {
                  customInput = it
                  viewModel.setCustomUserName(it)
                },
                label = { Text("Enter Custom Name") },
                modifier = Modifier.fillMaxWidth().testTag("custom_name_input"),
                colors = OutlinedTextFieldDefaults.colors(
                  focusedContainerColor = DarkSurface,
                  unfocusedContainerColor = DarkSurface,
                  focusedBorderColor = CyberCyan,
                  unfocusedBorderColor = Color(0xFF282C40),
                  focusedTextColor = TextPrimary,
                  unfocusedTextColor = TextPrimary
                )
              )
            }
          }
        }
      }

      // Romantic Personality Style
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth().testTag("personality_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Text(
              text = "Romantic Companion Style",
              style = MaterialTheme.typography.titleSmall,
              fontWeight = FontWeight.Bold,
              color = RoseRomantic
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
              text = "Adjust default emotional tone and playful banter response tendencies.",
              style = MaterialTheme.typography.bodySmall,
              color = TextSecondary
            )
            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
              PersonalityStyle.values().forEach { style ->
                Button(
                  onClick = { viewModel.setPersonalityStyle(style) },
                  colors = ButtonDefaults.buttonColors(
                    containerColor = if (personalityStyle == style) RoseRomantic else DarkSurface
                  ),
                  modifier = Modifier.weight(1f).testTag("style_${style.name}")
                ) {
                  Text(
                    text = style.name,
                    fontSize = 11.sp,
                    color = if (personalityStyle == style) Color.White else TextPrimary
                  )
                }
              }
            }
          }
        }
      }

      // Blush System & Atmosphere
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth().testTag("blush_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Blush Screen & Glow Effects", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Adapts screen tint, sparkles, and ambient glow during romantic reactions", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
              }
              Switch(
                checked = blushEnabled,
                onCheckedChange = { viewModel.setBlushEnabled(it) },
                colors = SwitchDefaults.colors(checkedThumbColor = RoseRomantic, checkedTrackColor = RoseRomantic.copy(alpha = 0.4f)),
                modifier = Modifier.testTag("blush_toggle")
              )
            }

            if (blushEnabled) {
              Spacer(modifier = Modifier.height(12.dp))
              Text("Effect Intensity: ${"%.0f".format(blushIntensity * 100)}%", fontSize = 12.sp, color = TextSecondary)
              Slider(
                value = blushIntensity,
                onValueChange = { viewModel.setBlushIntensity(it) },
                valueRange = 0.2f..1.0f,
                colors = SliderDefaults.colors(thumbColor = RoseRomantic, activeTrackColor = RoseRomantic),
                modifier = Modifier.testTag("blush_slider")
              )
            }
          }
        }
      }

      // Voice & Speech Engine Settings
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF282C40)),
          modifier = Modifier.fillMaxWidth().testTag("speech_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Column {
                Text("Speech Synthesis (TTS)", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
                Text("Warm feminine voice auto-reading companion responses", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
              }
              Switch(
                checked = autoSpeak,
                onCheckedChange = { viewModel.setAutoSpeak(it) },
                colors = SwitchDefaults.colors(checkedThumbColor = CyberCyan, checkedTrackColor = CyberCyan.copy(alpha = 0.4f)),
                modifier = Modifier.testTag("autospeak_toggle")
              )
            }

            Spacer(modifier = Modifier.height(12.dp))
            Button(
              onClick = {
                viewModel.speechManager.speak("Testing speech synthesis for Miss Perfect. Core audio verified.", viewModel.companionMode.value)
              },
              colors = ButtonDefaults.buttonColors(containerColor = DarkSurfaceHighlight),
              modifier = Modifier.fillMaxWidth().testTag("test_voice_button")
            ) {
              Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Test Voice Synthesis", color = CyberCyan, fontSize = 12.sp)
            }
          }
        }
      }

      // Truthful Capability Registry
      item {
        Text("Truthful Capability Registry", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
        Spacer(modifier = Modifier.height(2.dp))
        Text("Transparent status of all modules (no simulated fake claims)", style = MaterialTheme.typography.bodySmall, color = TextSecondary)
      }

      items(capabilities) { cap ->
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurfaceElevated),
          border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF242738)),
          modifier = Modifier.fillMaxWidth()
        ) {
          Column(modifier = Modifier.padding(12.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically
            ) {
              Text(cap.moduleName, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = TextPrimary)

              Surface(
                shape = RoundedCornerShape(6.dp),
                color = when (cap.status) {
                  CapabilityState.WORKING_VERIFIED -> SuccessEmerald.copy(alpha = 0.15f)
                  CapabilityState.NEEDS_PERMISSION -> WarningAmber.copy(alpha = 0.15f)
                  CapabilityState.NEEDS_PROVIDER -> IceBlue.copy(alpha = 0.15f)
                  CapabilityState.EXPERIMENTAL -> CalibratedPurple.copy(alpha = 0.15f)
                  CapabilityState.PLANNED -> Color(0xFF40445C)
                }
              ) {
                Text(
                  text = cap.status.label,
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  fontSize = 10.sp,
                  fontWeight = FontWeight.Bold,
                  color = when (cap.status) {
                    CapabilityState.WORKING_VERIFIED -> SuccessEmerald
                    CapabilityState.NEEDS_PERMISSION -> WarningAmber
                    CapabilityState.NEEDS_PROVIDER -> IceBlue
                    CapabilityState.EXPERIMENTAL -> CalibratedPurple
                    CapabilityState.PLANNED -> TextSecondary
                  }
                )
              }
            }

            Spacer(modifier = Modifier.height(4.dp))
            Text(cap.description, style = MaterialTheme.typography.bodySmall, color = TextSecondary, fontSize = 11.sp)
            Spacer(modifier = Modifier.height(2.dp))
            Text(cap.technicalNote, style = MaterialTheme.typography.bodySmall, color = TextTertiary, fontSize = 10.sp)
          }
        }
      }

      // About RIPPER & MISS PERFECT
      item {
        Card(
          shape = RoundedCornerShape(16.dp),
          colors = CardDefaults.cardColors(containerColor = DarkSurface),
          border = androidx.compose.foundation.BorderStroke(1.dp, CyberCyan.copy(alpha = 0.3f)),
          modifier = Modifier.fillMaxWidth().testTag("about_card")
        ) {
          Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(Icons.Default.Info, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("System Identity & Specifications", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = TextPrimary)
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text("Public Name: MISS PERFECT", color = IceBlue, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("Assistant Identity: RIPPER", color = TextPrimary, fontSize = 12.sp)
            Text("Full Title: Ripper of the Far and Beyond", color = TextSecondary, fontSize = 12.sp)
            Text("Tag: #GrandMaster", color = CyberCyan, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(6.dp))
            Text("Architecture: Local-first SQLite Room + Hybrid Gemini 2.5 Flash + Bioscience Calculation Engine + Android TTS/STT.", color = TextTertiary, fontSize = 11.sp)
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(24.dp))
      }
    }
  }
}
