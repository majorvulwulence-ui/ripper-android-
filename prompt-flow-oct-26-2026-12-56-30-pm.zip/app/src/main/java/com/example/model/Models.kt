package com.example.model

enum class CoreStatus {
  ACTIVE,
  STANDBY,
  SHUTDOWN,
  RESTARTING
}

enum class CompanionMode {
  GIRLFRIEND, // Adina or Karima
  ASSISTANT   // Ripper of the Far and Beyond (#GrandMaster)
}

enum class PersonalityStyle {
  SWEET,
  SHY,
  CHEEKY,
  BOLD
}

enum class UserPreferredName(val displayName: String) {
  RICHARD("Richard"),
  RASHID("Rashid"),
  ARIEL("Ariel"),
  NATURAL_ROTATION("Natural Variation"),
  CUSTOM("Custom")
}

enum class CompanionCanonicalName(val displayName: String) {
  ADINA("Adina"),
  KARIMA("Karima")
}

enum class AffectionType(val label: String, val icon: String, val baseReaction: String) {
  PECK("Peck", "💋", "A sweet, fleeting peck!"),
  KISS("Kiss", "💖", "A tender, romantic kiss..."),
  HUG("Hug", "🤗", "A warm, comforting embrace!")
}

enum class EmotionTone {
  NEUTRAL,
  ROMANTIC,
  BLUSH,
  PLAYFUL_SASS,
  SCIENTIFIC,
  DRAMATIC
}

enum class Provenance(val label: String) {
  LOCAL_OFFLINE("Local Engine"),
  GEMINI_ONLINE("Gemini AI Online"),
  SAVED_MEMORY("Memory Vault")
}

enum class LanguageMode(val displayName: String, val code: String) {
  ENGLISH("English", "en"),
  NIGERIAN_PIDGIN("Nigerian Pidgin", "pcm"),
  ARABIC("العربية (Arabic)", "ar")
}

data class ChatMessage(
  val id: String,
  val sender: MessageSender,
  val text: String,
  val timestamp: Long = System.currentTimeMillis(),
  val mode: CompanionMode = CompanionMode.GIRLFRIEND,
  val emotion: EmotionTone = EmotionTone.NEUTRAL,
  val language: LanguageMode = LanguageMode.ENGLISH,
  val provenance: Provenance = Provenance.LOCAL_OFFLINE
)

enum class MessageSender {
  USER,
  COMPANION,
  SYSTEM
}

enum class MemoryCategory(val label: String) {
  PERSONAL("Personal"),
  CONVERSATIONS("Conversations"),
  RESEARCH_LAB("Research Lab"),
  PROJECTS("Projects"),
  SYSTEM_BACKUPS("Backups"),
  PERSONALITY("Personality")
}

data class MemoryItem(
  val id: Long = 0,
  val category: MemoryCategory,
  val title: String,
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
  val isSyncedToDrive: Boolean = false,
  val provenance: String = "User Interaction"
)

enum class EpistemicStatus(val label: String, val description: String) {
  FACT("Established Fact", "Empirically verified through replicated evidence"),
  INFERENCE("Inference", "Deductive or inductive conclusion derived from verified premises"),
  HYPOTHESIS("Hypothesis", "Testable proposition awaiting experimental falsification"),
  SIMULATION("Simulation", "Algorithmic model output based on constrained assumptions"),
  SPECULATION("Speculation", "Theoretical conjecture with limited empirical constraints"),
  UNKNOWN("Unknown", "Current frontier of knowledge or data deficit")
}

data class CitationSource(
  val title: String,
  val publisher: String,
  val date: String,
  val url: String
)

data class ResearchEntry(
  val id: Long = 0,
  val title: String,
  val question: String,
  val hypothesis: String,
  val prediction: String,
  val method: String,
  val dataSource: String,
  val result: String,
  val limitations: String,
  val conclusion: String,
  val epistemicStatus: EpistemicStatus,
  val citations: List<CitationSource> = emptyList(),
  val followUp: String = "",
  val timestamp: Long = System.currentTimeMillis()
)

data class ThoughtExperiment(
  val id: String,
  val title: String,
  val domain: String,
  val scenario: String,
  val questions: List<String>,
  val dialecticSummary: String
)

data class CuriosityItem(
  val id: String,
  val question: String,
  val category: String,
  val addedTimestamp: Long = System.currentTimeMillis(),
  val isInvestigated: Boolean = false
)

data class RizzScore(
  val smoothnessScore: Int,
  val sassScore: Int,
  val chemistryScore: Int,
  val feedback: String,
  val companionComeback: String
)

data class CodeProject(
  val id: String,
  val name: String,
  val language: String,
  val code: String,
  val executionOutput: String = "",
  val isCompiled: Boolean = false,
  val testResult: String = ""
)

data class LifeTask(
  val id: Long = 0,
  val title: String,
  val category: String,
  val priority: String, // High, Medium, Low
  val isCompleted: Boolean = false,
  val targetTime: String = ""
)

data class SystemHealthReport(
  val batteryPct: Int,
  val isCharging: Boolean,
  val ramUsage: String,
  val storageStatus: String,
  val networkStatus: String,
  val diagnosticNotice: String,
  val uncertaintyLevel: String
)

enum class CapabilityState(val label: String) {
  WORKING_VERIFIED("Working & Verified"),
  NEEDS_PERMISSION("Needs Permission"),
  NEEDS_PROVIDER("Requires API/Cloud"),
  EXPERIMENTAL("Experimental"),
  PLANNED("Planned Roadmap")
}

data class CapabilityItem(
  val moduleName: String,
  val description: String,
  val status: CapabilityState,
  val technicalNote: String
)
