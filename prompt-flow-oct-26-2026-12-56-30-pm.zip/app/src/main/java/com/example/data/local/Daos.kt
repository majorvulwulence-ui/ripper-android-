package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface MemoryDao {
  @Query("SELECT * FROM memories ORDER BY timestamp DESC")
  fun getAllMemories(): Flow<List<MemoryEntity>>

  @Query("SELECT * FROM memories WHERE category = :category ORDER BY timestamp DESC")
  fun getMemoriesByCategory(category: String): Flow<List<MemoryEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMemory(memory: MemoryEntity): Long

  @Update
  suspend fun updateMemory(memory: MemoryEntity)

  @Delete
  suspend fun deleteMemory(memory: MemoryEntity)

  @Query("DELETE FROM memories")
  suspend fun clearAll()
}

@Dao
interface ResearchDao {
  @Query("SELECT * FROM research_entries ORDER BY timestamp DESC")
  fun getAllResearch(): Flow<List<ResearchEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertResearch(research: ResearchEntity): Long

  @Delete
  suspend fun deleteResearch(research: ResearchEntity)
}

@Dao
interface TaskDao {
  @Query("SELECT * FROM tasks ORDER BY isCompleted ASC, id DESC")
  fun getAllTasks(): Flow<List<TaskEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTask(task: TaskEntity): Long

  @Update
  suspend fun updateTask(task: TaskEntity)

  @Delete
  suspend fun deleteTask(task: TaskEntity)
}

@Dao
interface ChatDao {
  @Query("SELECT * FROM chat_history ORDER BY timestamp ASC")
  fun getAllMessages(): Flow<List<ChatEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertMessage(message: ChatEntity)

  @Query("DELETE FROM chat_history")
  suspend fun clearHistory()
}
