package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "memories")
data class MemoryEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val category: String,
  val title: String,
  val content: String,
  val timestamp: Long,
  val isSyncedToDrive: Boolean = false,
  val provenance: String
)

@Entity(tableName = "research_entries")
data class ResearchEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val question: String,
  val hypothesis: String,
  val prediction: String,
  val method: String,
  val dataSource: String,
  val result: String,
  val limitations: String,
  val conclusion: String,
  val epistemicStatus: String,
  val citationsJson: String,
  val followUp: String,
  val timestamp: Long
)

@Entity(tableName = "tasks")
data class TaskEntity(
  @PrimaryKey(autoGenerate = true)
  val id: Long = 0,
  val title: String,
  val category: String,
  val priority: String,
  val isCompleted: Boolean,
  val targetTime: String
)

@Entity(tableName = "chat_history")
data class ChatEntity(
  @PrimaryKey
  val id: String,
  val sender: String,
  val text: String,
  val timestamp: Long,
  val mode: String,
  val emotion: String,
  val language: String,
  val provenance: String
)
