package com.example.data.speech

import android.content.Context
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import com.example.model.CompanionMode
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class SpeechManager(private val context: Context) : TextToSpeech.OnInitListener {

  private var tts: TextToSpeech? = null
  private var isTtsReady = false

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _isListening = MutableStateFlow(false)
  val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

  private val _speechAmplitude = MutableStateFlow(0f)
  val speechAmplitude: StateFlow<Float> = _speechAmplitude.asStateFlow()

  private var speechRecognizer: SpeechRecognizer? = null

  var voicePitch: Float = 1.25f // Soft feminine tone
  var speechRate: Float = 1.0f

  init {
    tts = TextToSpeech(context, this)
  }

  override fun onInit(status: Int) {
    if (status == TextToSpeech.SUCCESS) {
      tts?.let { engine ->
        engine.language = Locale.US
        isTtsReady = true
        engine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
          override fun onStart(utteranceId: String?) {
            _isSpeaking.value = true
          }

          override fun onDone(utteranceId: String?) {
            _isSpeaking.value = false
          }

          @Deprecated("Deprecated in Java")
          override fun onError(utteranceId: String?) {
            _isSpeaking.value = false
          }
        })
      }
    }
  }

  fun speak(text: String, mode: CompanionMode = CompanionMode.GIRLFRIEND) {
    if (!isTtsReady || tts == null) return

    val cleanText = text.replace(Regex("[*#_`\\[\\]]"), "").trim()
    if (cleanText.isEmpty()) return

    // In Girlfriend mode, slightly higher warmer pitch; in Assistant mode, crisp intelligent pitch
    val adjustedPitch = if (mode == CompanionMode.GIRLFRIEND) voicePitch * 1.08f else voicePitch
    tts?.setPitch(adjustedPitch.coerceIn(0.5f, 2.0f))
    tts?.setSpeechRate(speechRate.coerceIn(0.5f, 2.0f))

    val utteranceId = "utterance_${System.currentTimeMillis()}"
    tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
  }

  fun stopSpeaking() {
    tts?.stop()
    _isSpeaking.value = false
  }

  fun startListening(
    onResult: (String) -> Unit,
    onError: (String) -> Unit
  ) {
    if (!SpeechRecognizer.isRecognitionAvailable(context)) {
      onError("Speech recognition not supported on this device.")
      return
    }

    try {
      speechRecognizer?.destroy()
      speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
        setRecognitionListener(object : RecognitionListener {
          override fun onReadyForSpeech(params: Bundle?) {
            _isListening.value = true
          }

          override fun onBeginningOfSpeech() {
            _speechAmplitude.value = 0.5f
          }

          override fun onRmsChanged(rmsdB: Float) {
            _speechAmplitude.value = (rmsdB / 10f).coerceIn(0f, 1f)
          }

          override fun onBufferReceived(buffer: ByteArray?) {}

          override fun onEndOfSpeech() {
            _isListening.value = false
            _speechAmplitude.value = 0f
          }

          override fun onError(error: Int) {
            _isListening.value = false
            _speechAmplitude.value = 0f
            val message = when (error) {
              SpeechRecognizer.ERROR_NO_MATCH -> "No speech detected"
              SpeechRecognizer.ERROR_NETWORK -> "Network error during speech recognition"
              SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
              else -> "Speech recognition error code: $error"
            }
            onError(message)
          }

          override fun onResults(results: Bundle?) {
            _isListening.value = false
            val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
            if (!matches.isNullOrEmpty()) {
              onResult(matches[0])
            }
          }

          override fun onPartialResults(partialResults: Bundle?) {}
          override fun onEvent(eventType: Int, params: Bundle?) {}
        })
      }

      val intent = android.content.Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PROMPT, "Listening to you...")
      }
      speechRecognizer?.startListening(intent)
    } catch (e: Exception) {
      _isListening.value = false
      onError(e.localizedMessage ?: "Failed to start speech recognition")
    }
  }

  fun stopListening() {
    try {
      speechRecognizer?.stopListening()
    } catch (_: Exception) {}
    _isListening.value = false
  }

  fun destroy() {
    tts?.shutdown()
    speechRecognizer?.destroy()
  }
}
