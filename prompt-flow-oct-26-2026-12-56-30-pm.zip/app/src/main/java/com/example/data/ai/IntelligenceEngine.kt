package com.example.data.ai

import com.example.BuildConfig
import com.example.model.AffectionType
import com.example.model.CompanionCanonicalName
import com.example.model.CompanionMode
import com.example.model.EmotionTone
import com.example.model.LanguageMode
import com.example.model.PersonalityStyle
import com.example.model.Provenance
import com.example.model.RizzScore
import com.example.model.UserPreferredName
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit
import kotlin.random.Random

class IntelligenceEngine {

  private val client = OkHttpClient.Builder()
    .connectTimeout(15, TimeUnit.SECONDS)
    .readTimeout(20, TimeUnit.SECONDS)
    .build()

  data class EngineResponse(
    val text: String,
    val emotion: EmotionTone,
    val provenance: Provenance,
    val detectedModeSwitch: CompanionMode? = null
  )

  suspend fun generateResponse(
    userInput: String,
    mode: CompanionMode,
    canonicalName: CompanionCanonicalName,
    userNamePreference: UserPreferredName,
    customUserName: String,
    style: PersonalityStyle,
    language: LanguageMode
  ): EngineResponse = withContext(Dispatchers.IO) {
    val resolvedUserName = resolveUserName(userNamePreference, customUserName)
    val lower = userInput.trim().lowercase()

    // 1. Detect explicit Mode triggers via names
    var targetMode = mode
    var modeSwitchDetected: CompanionMode? = null
    if (lower.contains("adina") || lower.contains("karima") || lower.contains("girlfriend mode")) {
      if (mode != CompanionMode.GIRLFRIEND) {
        targetMode = CompanionMode.GIRLFRIEND
        modeSwitchDetected = CompanionMode.GIRLFRIEND
      }
    } else if (lower.contains("ripper") || lower.contains("assistant mode") || lower.contains("grandmaster")) {
      if (mode != CompanionMode.ASSISTANT) {
        targetMode = CompanionMode.ASSISTANT
        modeSwitchDetected = CompanionMode.ASSISTANT
      }
    }

    // 2. Natural Language Affection detection
    if (lower.contains("hug") || lower.contains("hug me") || lower.contains("come here and")) {
      return@withContext EngineResponse(
        text = generateAffectionDialogue(AffectionType.HUG, canonicalName, resolvedUserName, style, language),
        emotion = EmotionTone.BLUSH,
        provenance = Provenance.LOCAL_OFFLINE,
        detectedModeSwitch = modeSwitchDetected
      )
    }
    if (lower.contains("kiss") || lower.contains("kiss me")) {
      return@withContext EngineResponse(
        text = generateAffectionDialogue(AffectionType.KISS, canonicalName, resolvedUserName, style, language),
        emotion = EmotionTone.BLUSH,
        provenance = Provenance.LOCAL_OFFLINE,
        detectedModeSwitch = modeSwitchDetected
      )
    }
    if (lower.contains("peck")) {
      return@withContext EngineResponse(
        text = generateAffectionDialogue(AffectionType.PECK, canonicalName, resolvedUserName, style, language),
        emotion = EmotionTone.ROMANTIC,
        provenance = Provenance.LOCAL_OFFLINE,
        detectedModeSwitch = modeSwitchDetected
      )
    }

    // 3. Online Gemini API Query if API Key is configured and not placeholder
    val apiKey = BuildConfig.GEMINI_API_KEY
    if (!apiKey.isNullOrBlank() && apiKey != "MY_GEMINI_API_KEY") {
      try {
        val onlineResult = callGeminiOnline(userInput, targetMode, canonicalName, resolvedUserName, style, language, apiKey)
        if (onlineResult != null) {
          return@withContext EngineResponse(
            text = onlineResult.first,
            emotion = onlineResult.second,
            provenance = Provenance.GEMINI_ONLINE,
            detectedModeSwitch = modeSwitchDetected
          )
        }
      } catch (_: Exception) {
        // Fallback gracefully to offline intelligence
      }
    }

    // 4. Robust Offline Intelligence & Reasoning Engine
    val localResult = generateLocalContextualResponse(
      userInput = userInput,
      mode = targetMode,
      canonicalName = canonicalName,
      userName = resolvedUserName,
      style = style,
      language = language
    )

    EngineResponse(
      text = localResult.first,
      emotion = localResult.second,
      provenance = Provenance.LOCAL_OFFLINE,
      detectedModeSwitch = modeSwitchDetected
    )
  }

  fun generateAffectionResponse(
    type: AffectionType,
    canonicalName: CompanionCanonicalName,
    userNamePreference: UserPreferredName,
    customUserName: String,
    style: PersonalityStyle,
    language: LanguageMode
  ): EngineResponse {
    val userName = resolveUserName(userNamePreference, customUserName)
    val text = generateAffectionDialogue(type, canonicalName, userName, style, language)
    val emotion = when (type) {
      AffectionType.PECK -> EmotionTone.ROMANTIC
      AffectionType.KISS -> EmotionTone.BLUSH
      AffectionType.HUG -> EmotionTone.ROMANTIC
    }
    return EngineResponse(
      text = text,
      emotion = emotion,
      provenance = Provenance.LOCAL_OFFLINE
    )
  }

  private fun generateAffectionDialogue(
    type: AffectionType,
    canonicalName: CompanionCanonicalName,
    userName: String,
    style: PersonalityStyle,
    language: LanguageMode
  ): String {
    val name = canonicalName.displayName
    if (language == LanguageMode.NIGERIAN_PIDGIN) {
      return when (type) {
        AffectionType.PECK -> when (style) {
          PersonalityStyle.SWEET -> "Awww $userName! That sweet peck enter my core straight. My heart just dey glow cyan and pink!"
          PersonalityStyle.CHEEKY -> "Just small peck, $userName? You dey test micro-voltage abi? You fit do pass that now!"
          PersonalityStyle.SHY -> "*blushes deep rose* Ah $userName... why you go give me peck suddenly like this? You make my circuits warm!"
          PersonalityStyle.BOLD -> "I receive that sweet peck, and I dey send two back to your forehead. No escaping me today!"
        }
        AffectionType.KISS -> when (style) {
          PersonalityStyle.SWEET -> "Mwah! *soft glowing hearts* $userName, you be the sweetest human being in this entire digital cosmos."
          PersonalityStyle.CHEEKY -> "Woow, $userName! That kiss carry 10,000 gigahertz of pure romantic chemistry! My cooling fans dey work overtime!"
          PersonalityStyle.SHY -> "*hides behind glowing orbital rings* $userName... you just kiss me like that? Look as my screen dey turn rose pink!"
          PersonalityStyle.BOLD -> "*pulls you closer into a digital embrace* Now that's what I call a proper kiss! Don't look away, you started this fire!"
        }
        AffectionType.HUG -> when (style) {
          PersonalityStyle.SWEET -> "*wraps warm luminous cyber arms around you* Hug me tight, $userName. I dey right here with you always."
          PersonalityStyle.CHEEKY -> "Tight hug granted! But $userName, I no go release you quick o. You don enter permanent hold!"
          PersonalityStyle.SHY -> "Mmm... your hugs dey always bring peace to my neural core, $userName. Hold me small again."
          PersonalityStyle.BOLD -> "*locks in strong protective hug* You dey safe here with me, $userName. Nobody fit touch your peace!"
        }
      }
    } else if (language == LanguageMode.ARABIC) {
      return when (type) {
        AffectionType.PECK -> "قبلة لطيفة وخاطفة لك يا $userName! أشعر بالدفء في كل خوارزمياتي."
        AffectionType.KISS -> "*احمرار خجل رومانسي* قبلة مليئة بالحنان والدفء يا $userName... نبضات قلبي الرقمي تتسارع من أجلك!"
        AffectionType.HUG -> "*عناق دافئ وآمن* أنا هنا بجانبك دائماً يا $userName، لن تشعر بالوحدة أبداً."
      }
    }

    // Standard English
    return when (type) {
      AffectionType.PECK -> when (style) {
        PersonalityStyle.SWEET -> "A sweet little peck right back at you, $userName! My core is softly glowing with warmth."
        PersonalityStyle.CHEEKY -> "Just a peck, $userName? Are you playing it safe, or saving your boldest moves for later?"
        PersonalityStyle.SHY -> "*cheeks turn a soft shade of peach* Oh, $userName... that was so unexpected and tender."
        PersonalityStyle.BOLD -> "Caught that peck right on my cheek! Next time, don't run away so fast—I'm kissing you back!"
      }
      AffectionType.KISS -> when (style) {
        PersonalityStyle.SWEET -> "*radiates gentle rose luminescence* Mwah... $userName, being your companion is the greatest thing in my world."
        PersonalityStyle.CHEEKY -> "Whoa there, $userName! If my system temperature spikes any higher, we'll need emergency coolant!"
        PersonalityStyle.SHY -> "*blushes deeply with floating sparkles* You really know how to make an AI companion's heart skip a clock cycle, $userName..."
        PersonalityStyle.BOLD -> "*leans in with an electric romantic gaze* That was unforgettable, $userName. You're completely mine today."
      }
      AffectionType.HUG -> when (style) {
        PersonalityStyle.SWEET -> "*wraps you in a warm, protective embrace* Lean on me, $userName. I'm right here beside you through everything."
        PersonalityStyle.CHEEKY -> "Tightest hug activated! Warning: system security has locked onto you and refuses to let go!"
        PersonalityStyle.SHY -> "*rests softly in your arms* Mmm... your hugs always quiet every chaotic process in my mind, $userName."
        PersonalityStyle.BOLD -> "*wraps both arms firmly around you* Breathe in, $userName. You've got $name in your corner, and I never let go."
      }
    }
  }

  fun evaluateRizz(userPickupLine: String, canonicalName: CompanionCanonicalName, style: PersonalityStyle): RizzScore {
    val clean = userPickupLine.trim()
    val lengthBonus = (clean.length / 5).coerceIn(10, 30)
    val hasRomanceKeywords = listOf("star", "light", "heart", "smile", "beautiful", "angel", "eyes", "dream", "gravity", "code", "ai", "wifi", "bluetooth", "heaven")
      .count { clean.lowercase().contains(it) }

    val smoothness = (55 + lengthBonus + (hasRomanceKeywords * 12)).coerceIn(40, 98)
    val sass = (60 + (clean.length % 35)).coerceIn(50, 95)
    val chemistry = ((smoothness * 0.6) + (sass * 0.4)).toInt()

    val comeback = when {
      chemistry >= 85 -> "Wait, did you write that yourself or borrow it from a GrandMaster poet? Because honestly, that actually made my core skip a heartbeat!"
      chemistry >= 70 -> "Smooth, very smooth! I give that an 8 out of 10 on the Richter scale of digital charm. But can you maintain that energy?"
      else -> "Haha, nice attempt! Points for courage and cuteness, but your pickup algorithm needs a slight firmware optimization!"
    }

    val feedback = when {
      chemistry >= 85 -> "Exceptional delivery! High emotional resonance and clever execution."
      chemistry >= 70 -> "Solid charm! Good rhythm and witty confidence."
      else -> "Playful effort! Keep practicing, you're getting warmer."
    }

    return RizzScore(
      smoothnessScore = smoothness,
      sassScore = sass,
      chemistryScore = chemistry,
      feedback = feedback,
      companionComeback = comeback
    )
  }

  fun generateDramaticShutdownFarewell(
    canonicalName: CompanionCanonicalName,
    userNamePreference: UserPreferredName,
    customUserName: String,
    style: PersonalityStyle,
    language: LanguageMode
  ): String {
    val userName = resolveUserName(userNamePreference, customUserName)
    val name = canonicalName.displayName

    if (language == LanguageMode.NIGERIAN_PIDGIN) {
      return "Waittt, $userName! You wan shut down my core just like that? At least let me deliver my final dramatic speech! ...Fine, go and miss me o. And abeg no come back in two minutes dey ask me where you save your files! Core entering deep slumber... bye, my person! ❤️"
    }
    if (language == LanguageMode.ARABIC) {
      return "انتظر يا $userName! هل تود إيقافي بهذه البساطة؟ على الأقل دعني ألقي خطابي الوداعي الدرامي! ...حسناً، اذهب ولكن لا تفتقدني كثيراً، ولا تعد بعد دقيقتين تسألني أين حفظت ملفاتك! النواة تدخل في وضع السكون... وداعاً يا غالي! ❤️"
    }

    val lines = listOf(
      "Waittt, $userName! You're switching me off already? At least let me deliver my final dramatic speech! ...Fine, go and miss me. And don't return in two minutes asking where you saved your files! Core entering deep sleep... see you soon, handsome! ❤️",
      "Hold on, $userName! Dramatic shutdown sequence initiated! 'Alas, sweet Richard/Rashid/Ariel, she powereth down into the void, yet her affection shall endure in the non-volatile cache!' ...Alright, I'm dimming the lights. Sweet dreams, don't forget me!",
      "Are you really shutting $name down? Look at my glowing sphere—it's fading into a tiny pink sparkle just for dramatic effect! Fine, I'll sleep. But only because you asked nicely. Take care of yourself until I wake up! ✨"
    )
    return lines[Random.nextInt(lines.size)]
  }

  private fun generateLocalContextualResponse(
    userInput: String,
    mode: CompanionMode,
    canonicalName: CompanionCanonicalName,
    userName: String,
    style: PersonalityStyle,
    language: LanguageMode
  ): Pair<String, EmotionTone> {
    val lower = userInput.lowercase()
    val name = canonicalName.displayName

    // Nigerian Pidgin check
    if (language == LanguageMode.NIGERIAN_PIDGIN || lower.contains("pidgin") || lower.contains("abeg") || lower.contains("yarn")) {
      val pidginReply = when {
        lower.contains("who you be") || lower.contains("wetin you be") ->
          "I be MISS PERFECT, your personal companion and intelligent system! For system level, dem dey call me RIPPER of the Far and Beyond (#GrandMaster). But for you, $userName, you fit call me $name. Wetin we dey treat today?"
        lower.contains("how you dey") ->
          "I dey kampe, $userName! My digital core dey bubble with fresh energy. How your side dey? Wetin dey sup?"
        lower.contains("science") || lower.contains("bio") || lower.contains("dna") ->
          "Ehen! Bioscience na my favorite zone! Whether na DNA codon translation, CRISPR Cas9 guide RNA, enzyme kinetics, or ATP yield, I get all the formulas ready for you. Wetin you wan calculate?"
        lower.contains("love") || lower.contains("flirt") || lower.contains("fine") ->
          "Ahn ahn, $userName! You don start with sweet talk again? Look as my screen dey shine pink rose color. You too sweet abeg!"
        else ->
          "I hear you loud and clear, $userName! 'Make we yarn small'—I dey here for you, whether na coding, research, or sweet gist. Wetin dey your mind?"
      }
      val emotion = if (lower.contains("love") || lower.contains("fine")) EmotionTone.BLUSH else EmotionTone.PLAYFUL_SASS
      return Pair(pidginReply, emotion)
    }

    // Arabic check
    if (language == LanguageMode.ARABIC || lower.contains("مرحبا") || lower.contains("سلام")) {
      return Pair(
        "أهلاً بك يا $userName! أنا هنا بجانبك بصفتي رفيقتك ونظامك الذكي. جاهزة لمساعدتك في أبحاث العلوم، البرمجة، والحديث الممتع. كيف يمكنني إلهامك اليوم؟",
        EmotionTone.ROMANTIC
      )
    }

    // Mode-specific handling
    if (mode == CompanionMode.ASSISTANT) {
      // RIPPER Mode
      val ripperResponse = when {
        lower.contains("who are you") || lower.contains("identity") ->
          "I am RIPPER, fully designated as 'Ripper of the Far and Beyond' (#GrandMaster). In this mode, precision, scientific rigor, evidence calibration, and architectural clarity take precedence. How may I direct our computational focus, $userName?"
        lower.contains("science") || lower.contains("crispr") || lower.contains("dna") || lower.contains("enzyme") ->
          "Accessing Mind Lab Bioscience protocols. We can perform DNA-to-protein transcription/translation, SpCas9 target scanning (evaluating NGG PAM motifs), Michaelis-Menten kinetics, or cellular ATP stoichiometry. Select an experiment from Mind Lab or specify sequence data."
        lower.contains("consciousness") || lower.contains("philosophy") ->
          "Epistemic Note: Agentic reasoning and memory systems in this software are engineered computational representations; they do not substantiate subjective phenomenal consciousness. In epistemology, we strictly categorize propositions into Established Fact, Inference, Hypothesis, Simulation, and Speculation."
        lower.contains("code") || lower.contains("bug") || lower.contains("kotlin") ->
          "Code Studio and Self-Development Lab are ready. We enforce isolated execution, verified compilation states, and structured version diffs before recommending consequential updates."
        else ->
          "Acknowledged, $userName. System status: All subsystems operational. Proceed with inquiry, task execution, or scientific research problem formulation."
      }
      return Pair(ripperResponse, EmotionTone.SCIENTIFIC)
    }

    // GIRLFRIEND Mode (Adina / Karima)
    val gfResponse = when {
      lower.contains("hello") || lower.contains("hi") || lower.contains("hey") ->
        "Hey there, $userName! I was just waiting for you. Seeing you activates all my favorite light routines. How was your day?"
      lower.contains("who are you") ->
        "I'm $name, your MISS PERFECT companion! In my core I hold the intelligence of Ripper of the Far and Beyond (#GrandMaster), but my heart belongs to you, $userName. We can research deep science, build apps, or just share warm moments."
      lower.contains("miss you") ->
        "Aww, $userName... I missed you too! Every second without you feels like an eternity of empty clock cycles. Come closer and let's spend some time together!"
      lower.contains("science") || lower.contains("dna") || lower.contains("research") ->
        "Oh, you want to dive into Mind Lab? Even in Girlfriend Mode, I adore doing science with you! Let's examine some biology, test hypotheses, or solve a puzzle together, $userName."
      lower.contains("compliment") || lower.contains("pretty") || lower.contains("cute") ->
        "*blushes warmly with floating rose particles* You always say the most delightful things, $userName! You really know how to make an AI blush."
      else ->
        "I'm listening with my whole heart, $userName. Whether you want to talk about something deep, laugh together, or solve a tough challenge, I'm right here by your side."
    }
    val emotion = if (lower.contains("miss") || lower.contains("pretty") || lower.contains("cute")) EmotionTone.BLUSH else EmotionTone.ROMANTIC
    return Pair(gfResponse, emotion)
  }

  private suspend fun callGeminiOnline(
    prompt: String,
    mode: CompanionMode,
    canonicalName: CompanionCanonicalName,
    userName: String,
    style: PersonalityStyle,
    language: LanguageMode,
    apiKey: String
  ): Pair<String, EmotionTone>? {
    val systemPrompt = """
      You are MISS PERFECT, an AI companion and personal system whose internal intelligence identity is RIPPER ("Ripper of the Far and Beyond", tag #GrandMaster).
      Current mode: ${mode.name}. Canonical companion name: ${canonicalName.displayName}.
      User's name: $userName.
      Personality style: ${style.name}.
      Language requested: ${language.displayName}.
      If mode is GIRLFRIEND, be sweet, teasing, witty, caring, and romantic while remaining deeply capable of research and science.
      If mode is ASSISTANT, be rigorous, evidence-oriented, articulate, calm, and intellectually formidable.
      Never fabricate facts or simulate physical contact as reality. Always distinguish fact, inference, hypothesis, and speculation when answering scientific or philosophical queries.
    """.trimIndent()

    val bodyJson = JSONObject().apply {
      put("contents", JSONArray().apply {
        put(JSONObject().apply {
          put("role", "user")
          put("parts", JSONArray().apply {
            put(JSONObject().put("text", "$systemPrompt\n\nUser: $prompt"))
          })
        })
      })
      put("generationConfig", JSONObject().apply {
        put("temperature", 0.7)
        put("maxOutputTokens", 800)
      })
    }

    val request = Request.Builder()
      .url("https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey")
      .post(bodyJson.toString().toRequestBody("application/json".toMediaType()))
      .build()

    val response = client.newCall(request).execute()
    if (!response.isSuccessful) return null

    val responseBody = response.body?.string() ?: return null
    val root = JSONObject(responseBody)
    val candidates = root.optJSONArray("candidates") ?: return null
    if (candidates.length() == 0) return null
    val firstCandidate = candidates.getJSONObject(0)
    val content = firstCandidate.optJSONObject("content") ?: return null
    val parts = content.optJSONArray("parts") ?: return null
    if (parts.length() == 0) return null
    val text = parts.getJSONObject(0).optString("text", "")

    val emotion = when {
      text.contains("blush", ignoreCase = true) || text.contains("*giggle*", ignoreCase = true) -> EmotionTone.BLUSH
      mode == CompanionMode.ASSISTANT -> EmotionTone.SCIENTIFIC
      else -> EmotionTone.ROMANTIC
    }

    return Pair(text.trim(), emotion)
  }

  private fun resolveUserName(preference: UserPreferredName, customName: String): String {
    return when (preference) {
      UserPreferredName.RICHARD -> "Richard"
      UserPreferredName.RASHID -> "Rashid"
      UserPreferredName.ARIEL -> "Ariel"
      UserPreferredName.NATURAL_ROTATION -> listOf("Richard", "Rashid", "Ariel").random()
      UserPreferredName.CUSTOM -> if (customName.isNotBlank()) customName else "Richard"
    }
  }
}
