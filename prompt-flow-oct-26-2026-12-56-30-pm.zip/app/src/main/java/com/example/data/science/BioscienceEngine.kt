package com.example.data.science

object BioscienceEngine {

  // Standard Genetic Code codon table
  private val codonTable = mapOf(
    "UUU" to "Phe (F)", "UUC" to "Phe (F)",
    "UUA" to "Leu (L)", "UUG" to "Leu (L)",
    "CUU" to "Leu (L)", "CUC" to "Leu (L)", "CUA" to "Leu (L)", "CUG" to "Leu (L)",
    "AUU" to "Ile (I)", "AUC" to "Ile (I)", "AUA" to "Ile (I)",
    "AUG" to "Met (M) [START]",
    "GUU" to "Val (V)", "GUC" to "Val (V)", "GUA" to "Val (V)", "GUG" to "Val (V)",
    "UCU" to "Ser (S)", "UCC" to "Ser (S)", "UCA" to "Ser (S)", "UCG" to "Ser (S)",
    "CCU" to "Pro (P)", "CCC" to "Pro (P)", "CCA" to "Pro (P)", "CCG" to "Pro (P)",
    "ACU" to "Thr (T)", "ACC" to "Thr (T)", "ACA" to "Thr (T)", "ACG" to "Thr (T)",
    "GCU" to "Ala (A)", "GCC" to "Ala (A)", "GCA" to "Ala (A)", "GCG" to "Ala (A)",
    "UAU" to "Tyr (Y)", "UAC" to "Tyr (Y)",
    "UAA" to "[STOP]", "UAG" to "[STOP]", "UGA" to "[STOP]",
    "CAU" to "His (H)", "CAC" to "His (H)",
    "CAA" to "Gln (Q)", "CAG" to "Gln (Q)",
    "AAU" to "Asn (N)", "AAC" to "Asn (N)",
    "AAA" to "Lys (K)", "AAG" to "Lys (K)",
    "GAU" to "Asp (D)", "GAC" to "Asp (D)",
    "GAA" to "Glu (E)", "GAG" to "Glu (E)",
    "UGU" to "Cys (C)", "UGC" to "Cys (C)",
    "UGG" to "Trp (W)",
    "CGU" to "Arg (R)", "CGC" to "Arg (R)", "CGA" to "Arg (R)", "CGG" to "Arg (R)",
    "AGU" to "Ser (S)", "AGC" to "Ser (S)",
    "AGA" to "Arg (R)", "AGG" to "Arg (R)",
    "GGU" to "Gly (G)", "GGC" to "Gly (G)", "GGA" to "Gly (G)", "GGG" to "Gly (G)"
  )

  data class DnaTranslationResult(
    val cleanDna: String,
    val mrna: String,
    val codons: List<String>,
    val aminoAcids: List<String>,
    val polypeptideSequence: String,
    val molecularWeightEstimateDa: Double,
    val gcContentPercent: Double
  )

  fun translateDnaSequence(dnaInput: String): DnaTranslationResult {
    val clean = dnaInput.uppercase().filter { it in "ATCG" }
    val mrna = clean.replace('T', 'U')

    val codons = mutableListOf<String>()
    var i = 0
    while (i + 3 <= mrna.length) {
      codons.add(mrna.substring(i, i + 3))
      i += 3
    }

    val aminoAcids = codons.map { codon ->
      codonTable[codon] ?: "Unknown"
    }

    val polypeptide = aminoAcids.joinToString(" - ")
    val avgAaWeightDa = 110.0
    val weightEst = aminoAcids.size * avgAaWeightDa

    val gcCount = clean.count { it == 'G' || it == 'C' }
    val gcPercent = if (clean.isNotEmpty()) (gcCount.toDouble() / clean.length) * 100.0 else 0.0

    return DnaTranslationResult(
      cleanDna = clean,
      mrna = mrna,
      codons = codons,
      aminoAcids = aminoAcids,
      polypeptideSequence = if (polypeptide.isEmpty()) "Sequence too short (< 3 nt)" else polypeptide,
      molecularWeightEstimateDa = weightEst,
      gcContentPercent = gcPercent
    )
  }

  data class CrisprTarget(
    val position: Int,
    val protospacer20nt: String,
    val pamSite: String,
    val gcContentPercent: Double,
    val qualityScore: Int
  )

  fun scanCrisprCas9Targets(dnaSequence: String): List<CrisprTarget> {
    val clean = dnaSequence.uppercase().filter { it in "ATCG" }
    val targets = mutableListOf<CrisprTarget>()

    // Cas9 SpCas9 PAM is NGG (any base followed by GG)
    for (i in 20 until clean.length - 2) {
      if (clean[i + 1] == 'G' && clean[i + 2] == 'G') {
        val protospacer = clean.substring(i - 20, i)
        val pam = clean.substring(i, i + 3)
        val gc = protospacer.count { it == 'G' || it == 'C' }
        val gcPercent = (gc.toDouble() / 20.0) * 100.0

        // Optimal GC for SpCas9 gRNA is 40% - 60%
        val quality = when {
          gcPercent in 40.0..60.0 -> 95
          gcPercent in 30.0..70.0 -> 80
          else -> 55
        }

        targets.add(
          CrisprTarget(
            position = i - 20,
            protospacer20nt = protospacer,
            pamSite = pam,
            gcContentPercent = gcPercent,
            qualityScore = quality
          )
        )
      }
    }
    return targets
  }

  data class EnzymeKineticsResult(
    val substrateConcentrations: List<Double>,
    val velocities: List<Double>,
    val km: Double,
    val vmax: Double,
    val halfMaxVelocity: Double,
    val lineweaverBurkSlope: Double, // Km / Vmax
    val lineweaverBurkYIntercept: Double // 1 / Vmax
  )

  fun computeEnzymeKinetics(
    km: Double,
    vmax: Double,
    maxSubstrate: Double = 50.0
  ): EnzymeKineticsResult {
    val steps = 10
    val substratePoints = (1..steps).map { (it * maxSubstrate) / steps }
    val velocities = substratePoints.map { s ->
      (vmax * s) / (km + s)
    }

    val slope = if (vmax > 0) km / vmax else 0.0
    val yInt = if (vmax > 0) 1.0 / vmax else 0.0

    return EnzymeKineticsResult(
      substrateConcentrations = substratePoints,
      velocities = velocities,
      km = km,
      vmax = vmax,
      halfMaxVelocity = vmax / 2.0,
      lineweaverBurkSlope = slope,
      lineweaverBurkYIntercept = yInt
    )
  }

  data class CellularRespirationYield(
    val glucoseMolecules: Int,
    val glycolysisAtpNet: Int,
    val glycolysisNadh: Int,
    val pyruvateOxidationNadh: Int,
    val krebsCycleAtpGtp: Int,
    val krebsCycleNadh: Int,
    val krebsCycleFadh2: Int,
    val totalNadh: Int,
    val totalFadh2: Int,
    val oxidativePhosphorylationAtp: Double,
    val totalAtpTheoretical: Double
  )

  fun calculateAtpYield(glucoseCount: Int): CellularRespirationYield {
    val g = glucoseCount.coerceAtLeast(1)
    val glyAtp = 2 * g
    val glyNadh = 2 * g
    val pyrNadh = 2 * g
    val krebAtp = 2 * g
    val krebNadh = 6 * g
    val krebFadh2 = 2 * g

    val totNadh = glyNadh + pyrNadh + krebNadh
    val totFadh2 = krebFadh2

    // Modern P/O ratio: 2.5 ATP per NADH, 1.5 ATP per FADH2
    val oxPhosAtp = (totNadh * 2.5) + (totFadh2 * 1.5)
    val totalNet = glyAtp + krebAtp + oxPhosAtp

    return CellularRespirationYield(
      glucoseMolecules = g,
      glycolysisAtpNet = glyAtp,
      glycolysisNadh = glyNadh,
      pyruvateOxidationNadh = pyrNadh,
      krebsCycleAtpGtp = krebAtp,
      krebsCycleNadh = krebNadh,
      krebsCycleFadh2 = krebFadh2,
      totalNadh = totNadh,
      totalFadh2 = totFadh2,
      oxidativePhosphorylationAtp = oxPhosAtp,
      totalAtpTheoretical = totalNet
    )
  }
}
