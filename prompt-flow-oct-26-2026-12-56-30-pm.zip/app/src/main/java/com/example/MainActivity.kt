package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.Science
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.TaskAlt
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.NavigationRailItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.core.BlushOverlay
import com.example.ui.core.ShutdownDialog
import com.example.ui.screens.CodeStudioScreen
import com.example.ui.screens.CompanionScreen
import com.example.ui.screens.KnowledgeVaultScreen
import com.example.ui.screens.LifeManagerScreen
import com.example.ui.screens.MindLabScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.CyberCyan
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceElevated
import com.example.ui.theme.DeepVoid
import com.example.ui.theme.MissPerfectTheme
import com.example.ui.theme.RoseRomantic
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.AppScreen
import com.example.viewmodel.MissPerfectViewModel

class MainActivity : ComponentActivity() {

  private val viewModel: MissPerfectViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    setContent {
      MissPerfectTheme {
        MissPerfectApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun MissPerfectApp(viewModel: MissPerfectViewModel) {
  val currentScreen by viewModel.currentScreen.collectAsState()
  val isBlushing by viewModel.isBlushing.collectAsState()
  val blushIntensity by viewModel.blushIntensity.collectAsState()
  val blushEnabled by viewModel.blushEnabled.collectAsState()
  val showShutdownDialog by viewModel.showShutdownDialog.collectAsState()
  val farewellSpeech by viewModel.farewellSpeech.collectAsState()

  // Handle back button on secondary screens
  BackHandler(enabled = currentScreen != AppScreen.COMPANION) {
    viewModel.setScreen(AppScreen.COMPANION)
  }

  val config = LocalConfiguration.current
  val isExpandedWidth = config.screenWidthDp >= 600

  val navItems = listOf(
    Triple(AppScreen.COMPANION, "Companion", Icons.Default.Favorite),
    Triple(AppScreen.MIND_LAB, "Mind Lab", Icons.Default.Science),
    Triple(AppScreen.CODE_STUDIO, "Code Studio", Icons.Default.Code),
    Triple(AppScreen.LIFE_MANAGER, "Commander", Icons.Default.TaskAlt),
    Triple(AppScreen.KNOWLEDGE_VAULT, "Vault", Icons.Default.Folder),
    Triple(AppScreen.SETTINGS, "Settings", Icons.Default.Settings)
  )

  Box(modifier = Modifier.fillMaxSize().background(DeepVoid)) {
    if (isExpandedWidth) {
      // Tablet / Foldable landscape layout with NavigationRail
      Row(modifier = Modifier.fillMaxSize()) {
        NavigationRail(
          containerColor = DarkSurfaceElevated,
          contentColor = CyberCyan,
          modifier = Modifier.fillMaxHeight().testTag("app_navigation_rail")
        ) {
          navItems.forEach { (screen, label, icon) ->
            NavigationRailItem(
              selected = currentScreen == screen,
              onClick = { viewModel.setScreen(screen) },
              icon = { Icon(icon, contentDescription = label, modifier = Modifier.size(20.dp)) },
              label = { Text(label, fontSize = 11.sp) },
              colors = NavigationRailItemDefaults.colors(
                selectedIconColor = DeepVoid,
                selectedTextColor = CyberCyan,
                unselectedIconColor = TextSecondary,
                unselectedTextColor = TextSecondary,
                indicatorColor = CyberCyan
              ),
              modifier = Modifier.testTag("nav_item_${screen.name}")
            )
          }
        }

        Box(modifier = Modifier.weight(1f).fillMaxHeight()) {
          MainContentHost(currentScreen = currentScreen, viewModel = viewModel)
        }
      }
    } else {
      // Mobile vertical layout with bottom NavigationBar
      Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = DeepVoid,
        bottomBar = {
          NavigationBar(
            containerColor = DarkSurface,
            tonalElevation = 8.dp,
            modifier = Modifier.testTag("app_bottom_bar")
          ) {
            navItems.forEach { (screen, label, icon) ->
              val isSelected = currentScreen == screen
              NavigationBarItem(
                selected = isSelected,
                onClick = { viewModel.setScreen(screen) },
                icon = {
                  Icon(
                    imageVector = icon,
                    contentDescription = label,
                    modifier = Modifier.size(22.dp)
                  )
                },
                label = {
                  Text(
                    text = label,
                    fontSize = 10.sp,
                    maxLines = 1
                  )
                },
                colors = NavigationBarItemDefaults.colors(
                  selectedIconColor = DeepVoid,
                  selectedTextColor = if (screen == AppScreen.COMPANION) RoseRomantic else CyberCyan,
                  unselectedIconColor = TextSecondary,
                  unselectedTextColor = TextSecondary,
                  indicatorColor = if (screen == AppScreen.COMPANION) RoseRomantic else CyberCyan
                ),
                modifier = Modifier.testTag("nav_item_${screen.name}")
              )
            }
          }
        }
      ) { innerPadding ->
        Box(
          modifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)
        ) {
          MainContentHost(currentScreen = currentScreen, viewModel = viewModel)
        }
      }
    }

    // Atmospheric Blush Overlay (when companion reacts shy/romantic)
    BlushOverlay(
      isBlushing = isBlushing,
      intensity = blushIntensity,
      enabled = blushEnabled
    )

    // Dramatic Shutdown Farewell Dialog
    if (showShutdownDialog) {
      ShutdownDialog(
        farewellSpeech = farewellSpeech,
        onConfirmShutdown = { viewModel.confirmShutdown() },
        onSkipFarewell = { viewModel.skipFarewellAndShutdown() },
        onCancel = { viewModel.cancelShutdown() }
      )
    }
  }
}

@Composable
fun MainContentHost(
  currentScreen: AppScreen,
  viewModel: MissPerfectViewModel
) {
  when (currentScreen) {
    AppScreen.COMPANION -> CompanionScreen(viewModel = viewModel)
    AppScreen.MIND_LAB -> MindLabScreen(viewModel = viewModel)
    AppScreen.CODE_STUDIO -> CodeStudioScreen(viewModel = viewModel)
    AppScreen.LIFE_MANAGER -> LifeManagerScreen(viewModel = viewModel)
    AppScreen.KNOWLEDGE_VAULT -> KnowledgeVaultScreen(viewModel = viewModel)
    AppScreen.SETTINGS -> SettingsScreen(viewModel = viewModel)
  }
}
