package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.science.BioscienceEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun readStringFromContext() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("MISS PERFECT", appName)
  }

  @Test
  fun testBioscienceDnaTranslation() {
    val dna = "ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAG"
    val result = BioscienceEngine.translateDnaSequence(dna)
    assertNotNull(result)
    assertTrue(result.mrna.startsWith("AUG"))
    assertTrue(result.codons.isNotEmpty())
    assertTrue(result.gcContentPercent > 0.0)
  }

  @Test
  fun testCrisprScanner() {
    val targetDna = "ATGGCCATTGTAATGGGCCGCTGAAAGGGTGCCCGATAGCCATGGCGATCGATCGATC"
    val targets = BioscienceEngine.scanCrisprCas9Targets(targetDna)
    assertNotNull(targets)
    // Must find NGG PAM targets
    targets.forEach { target ->
      assertTrue(target.pamSite.endsWith("GG"))
      assertEquals(20, target.protospacer20nt.length)
    }
  }

  @Test
  fun testEnzymeKinetics() {
    val km = 5.0
    val vmax = 20.0
    val result = BioscienceEngine.computeEnzymeKinetics(km, vmax)
    assertEquals(10.0, result.halfMaxVelocity, 0.001)
    assertEquals(km / vmax, result.lineweaverBurkSlope, 0.001)
  }
}
